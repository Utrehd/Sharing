# Date:	 		18.06.2017
# Creator:  	SAM
# Description:	This is the main file for the assignment statistical

import parameters
from lib import list_formatting, statistical_analysis, txt_reporter, txt_reader

# Create a new reader in order to Read the DataSet in
reporter = txt_reporter.Reporter(parameters.userName, parameters.description)

# Start the Report
reporter.print_header()

# Print the amount of Readers
reporter.report("Number of Reporters: " + str(txt_reporter.Reporter.count))

# Read The data in from the .txt file
dataSet = txt_reader.read_txt(parameters.dataSetDir)

# Strip away all the new lines
dataSet = list_formatting.strip(dataSet, '\n')

# Convert DataSet to Int for proper processing later
dataSet = list_formatting.convert_to_int(dataSet)

# Print the Data-set
reporter.new_lines(1)
reporter.report("Data-set Raw in INT:\n" + str(dataSet))

# Sort the Data Ascending
dataSetAscending = list_formatting.sort_ascending(dataSet)
reporter.new_lines(1)
reporter.report("Data-set Ascending:\n" + str(dataSetAscending))

# Sort the Data Descending
dataSetDescending = list_formatting.sort_descending(dataSet)
reporter.new_lines(1)
reporter.report("Data-set Descending:\n" + str(dataSetDescending))

# Get Mean
mean = statistical_analysis.get_mean(dataSet)
reporter.new_lines(1)
reporter.report("Data-set Mean:\n" + str(mean))

# Get the Deviation of the data-set regarding the mean value
deviationMean = statistical_analysis.get_overall_deviation(dataSet, mean)
reporter.new_lines(1)
reporter.report("Deviation of Mean:\n" + str(deviationMean))

# Get Median
median = statistical_analysis.get_median(dataSet)
reporter.new_lines(1)
reporter.report("Data-set Median:\n" + str(median))

# Get the Deviation of the data set regarding the mean value
deviationMedian = statistical_analysis.get_overall_deviation(dataSet, median)
reporter.new_lines(1)
reporter.report("Deviation of Median:\n" + str(deviationMedian))

# Get Mod Value of Data-set
modeValue = statistical_analysis.get_modes(dataSet)
reporter.new_lines(1)
reporter.report("Frequency of Modes: " + str(list_formatting.get_highest_frequency(dataSet)))
reporter.report("Modes of Data-set: " + str(modeValue))

# Get range of Data-set
range_value = statistical_analysis.get_range(dataSet)
reporter.new_lines(1)
reporter.report("Range of Data-set:\n" + str(range_value))

# End the Report
reporter.finish_report()
