# Date: 18.06.2017
# V01
# These Functions are used to easy the txt file handling.


# Read the Text file into a list
def read_txt(file_dir):
	file = open(file_dir, 'r')
	lines = file.readlines()
	return lines
