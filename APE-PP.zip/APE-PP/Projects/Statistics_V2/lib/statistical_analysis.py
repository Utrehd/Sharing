"""
Date:	 		18.06.2017
Creator:  		SAM
Description:
This Module contains several methods for action statistical analysis over a set of data.
"""

from lib import list_formatting
from typing import List, Any


# Gets the Mean (Average) Value of a List
def get_mean(_list: List[int]) -> int:
	"""
	Returns the mean of a int list.

	:param _list: Target list.
	:return: Mean of input list.
	"""
	sum_of_list = list_formatting.get_sum(_list)
	mean = sum_of_list / len(_list)
	return int(mean)


# Gets the median value of a list
def get_median(_list: List[int]) -> int:
	"""
	Returns the median of a int list.

	:param _list: Target list.
	:return: Median of input list.
	"""
	# Sort the List ascending
	ascending_list = list_formatting.sort_ascending(_list)
	list_length = len(ascending_list)
	# If the list has an even length get the mean of the middle tow members
	if list_formatting.check_evenness_of_length(ascending_list):
		# Get First Value
		index = int((list_length - 1) / 2)
		value1 = ascending_list[index]

		# Get Second value
		index = int((list_length + 1) / 2)
		value2 = ascending_list[index]

		# Combine Values
		median = (value1 + value2) / 2
	# Else use the most middle member
	else:
		index = int((list_length / 2) - 0.5)
		median = ascending_list[index]
	return int(median)


# Get deviation of a whole list regarding one single value
def get_overall_deviation(_list: List[int], target_value: int) -> float:
	"""
	Return the overall deviation of a whole input list regarding the target value.

	:param _list: Target list.
	:param target_value: chosen value which is used as basis for the deviation calculation. usually the median or mean.

	:return: The Deviation
	"""
	# Copy list and create new one
	in_list = list(_list)
	# Get a List with all deviations regarding the passed value
	in_list = list_formatting.get_deviations_of_members(in_list, target_value)
	# Quadrate List
	in_list = list_formatting.exponentiate_members(in_list, 2)
	# Get Sum
	sum_of_list = list_formatting.get_sum(in_list)
	# Calculate mean of sum - Deviation in quadrant
	deviation_quadrate = sum_of_list / len(in_list)
	# root the sum
	deviation = deviation_quadrate ** 0.5
	# Return float with max 2 decimals
	return float("{0:.2f}".format(deviation))


# Get the all the modes of a list (most occurring member)
def get_modes(_list: List[Any]) -> List[Any]:
	"""
	Creates a list containing the modes of the input list

	:param _list: Input list
	:return: List of modes
	"""
	# Copy _list and create new one
	in_list = list(_list)
	# Get the highest frequency
	highest_frequency = list_formatting.get_highest_frequency(in_list)
	# If frequency is less than 1 than there is no mode.
	if highest_frequency > 1:
		modes = list_formatting.get_all_members_occurring_with_frequency(in_list, highest_frequency)
		modes = list_formatting.limit_max_member_frequency(modes, 1)
		return modes
	else:
		return ["None"]


# Gets the range of the given list from min to max value
def get_range(_list: List[int]) -> int:
	"""
	Get the nominal range of a the input list.

	:param _list: The input list
	:return: nominal range
	"""
	# Get the biggest and smallest Value
	biggest = list_formatting.get_biggest_member(_list)
	smallest = list_formatting.get_smallest_member(_list)
	# Get their range
	out_range = biggest - smallest
	return out_range
