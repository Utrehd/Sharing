# Date:	 		18.06.2017
# Creator:  	SAM
# Description:	This class allows user to create a .txt and report into the command line simultaneously.

# Imports:
import datetime
import parameters
import os


class Reporter:
	# This Shall Count the number of instances
	count = 0

	# Constructor
	def __init__(self, username, description):
		# Count up the number of instances
		Reporter.count += 1
		# get all the general information
		self.user = username
		self.description = description
		self.now = datetime.datetime.now()

		# Create dir if it is not existing yet.
		if not os.path.exists(parameters.report_dir):
			os.makedirs(parameters.report_dir)

		# Create a new .txt report in dir
		self.report_txt = open(parameters.report_dir + "\\Report" + str(Reporter.count) + ".txt", "w")

	# Prints the header of the report
	def print_header(self):
		self.new_lines(1)
		# Print Start Bar
		self.print_bar()
		# Print other Information
		self.report("User: " + str(self.user))
		self.report("Date: " + str(self.now))
		self.report("Description: " + str(self.description))

	# Creates x amount of new lines in the report
	def new_lines(self, amount=1):
		for i in range(amount):
			self.report("\n")

	# Finishes the report
	def finish_report(self):
		self.print_bar("/")
		# Close the txt file
		self.report_txt.close()

	# Prints a 80 character long bar with specified symbol
	def print_bar(self, symbol="#"):
		bar = symbol
		for i in range(79):
			bar += symbol
		self.report(bar)

	# This function reports in the command line and into the .txt
	def report(self, message):
		print(message)
		self.report_txt.write(message + "\n")
