# Date:	 		23.06.2017
# Creator:  	SAM
# Description:	This file is executing unit tests for the list_formatting.py functions

import unittest
from lib import list_formatting


class TestListFormattingMethod(unittest.TestCase):

	def test_strip(self):
		# Arrange
		in_list = ["das3", "4das", "das", "das53"]
		in_value = "das"
		exp_list = ["3", "4", "", "53"]
		out_list = []
		# Act
		out_list = list_formatting.strip(in_list, in_value)
		# Assert
		self.assertEqual(out_list,exp_list)

	def test_sort_ascending(self):
		# Arrange
		in_list = [32, 1, 91, 2, 9933]
		exp_list = [1, 2, 32, 91, 9933]
		# Act
		out_list = list_formatting.sort_ascending(in_list)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_sort_descending(self):
		# Arrange
		in_list = [32, 1, 91, 2, 9933]
		exp_list = [9933, 91, 32, 2, 1]
		# Act
		out_list = list_formatting.sort_descending(in_list)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_get_smallest_member(self):
		# Arrange
		in_list = [32, 43, 1, 77]
		exp_value = 1
		# Act
		out_value = list_formatting.get_smallest_member(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_get_biggest_member(self):
		# Arrange
		in_list = [32, 43, 1, 77]
		exp_value = 77
		# Act
		out_value = list_formatting.get_biggest_member(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_get_frequency_of_member(self):
		# Arrange
		in_list = [23, 23, 11, 11, 22, 11]
		in_member = 11
		exp_frequency = 3
		# Act
		out_frequency = list_formatting.get_frequency_of_member(in_list, in_member)
		# Assert
		self.assertEqual(out_frequency, exp_frequency)

	def test_get_highest_frequency(self):
		# Arrange
		in_list = [41, 33, 41, 1, 4, 5, 633, 33, 33, 22, 33]
		exp_frequency = 4
		# Act
		out_frequency = list_formatting.get_highest_frequency(in_list)
		# Assert
		self.assertEqual(out_frequency, exp_frequency)

	def test_get_all_members_occurring_with_frequency(self):
		# Arrange
		in_list = [32, 32, 1, 2, 4, 6, 6, 6, 4, 4, 32, 1, 77, 25]
		in_frequency = 3
		exp_members = [32, 32, 4, 6, 6, 6, 4, 4, 32]
		# Act
		out_members = list_formatting.get_all_members_occurring_with_frequency(in_list, in_frequency)
		# Assert
		self.assertEqual(out_members, exp_members)

	def test_wipe_frequencies(self):
		# Arrange
		in_list = [32, 32, 32, 1, 32, 23, 23, 4, 1, 4, 9, 1]
		exp_list = [32, 32, 23, 23, 4, 1, 4, 9, 1]
		# Act
		out_list = list_formatting.limit_max_member_frequency(in_list, 2)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_get_sum(self):
		# Arrange
		in_list = [20, 30, 10]
		exp_value = 60
		# Act
		out_value = list_formatting.get_sum(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_check_evenness_of_length(self):
		# Check Uneven
		# Arrange
		in_list = [1, 2, 3, 4, 5, 77, 99]
		exp_bool = False
		# Act
		out_bool = list_formatting.check_evenness_of_length(in_list)
		# Assert
		self.assertEqual(out_bool, exp_bool)

		# Check Even
		# Arrange
		in_list = [1, 2, 3, 4, 5, 88]
		exp_bool = True
		# Act
		out_bool = list_formatting.check_evenness_of_length(in_list)
		# Assert
		self.assertEqual(out_bool, exp_bool)

	def test_remove_member(self):
		# Arrange
		in_list = [22, 22, 22, 1, 5, 22, 1, 3, 22]
		in_member = 22
		exp_list = [1, 5, 1, 3]
		# Act
		out_list = list_formatting.remove_members(in_list, in_member)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_append_member_repeatedly(self):
		# Arrange
		in_list = [2, 3, 5, 1, 2]
		in_member = 43
		in_amount = 4
		exp_list = [2, 3, 5, 1, 2, 43, 43, 43, 43]
		# Act
		out_list = list_formatting.append_member_repeatedly(in_list, in_member, in_amount)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_convert_to_int(self):
		# Arrange
		in_list = ['32', '31', '5', '51']
		exp_list = [32, 31, 5, 51]
		# Act
		out_list = list_formatting.convert_to_int(in_list)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_deviations_of_members(self):
		# Arrange
		in_list = [1, 2, 3, 4, 100, 200]
		in_value = 10
		exp_list = [-9, -8, -7, -6, 90, 190]
		# Act
		out_list = list_formatting.get_deviations_of_members(in_list, in_value)
		# Assert
		self.assertEqual(out_list, exp_list)

	def test_exponentiate_members(self):
		# Arrange
		in_list = [1, 2, 4, 8, 16]
		in_exponent = 3
		exp_list = [1, 8, 64, 512, 4096]
		# Act
		out_list = list_formatting.exponentiate_members(in_list, in_exponent)
		# Assert
		self.assertEqual(out_list, exp_list)


if __name__ == '__main__':
	unittest.main()
