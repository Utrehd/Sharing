# Date:	 		18.06.2017
# Creator:  	SAM
# Description:	This is the Config File. It defins the main configurations

import os

# User Name is used for reporting
userName = "Samuel A. Marti"

# Directory of DataSet
dataSetDir = os.path.join(os.path.dirname(__file__), "DataSets/Set1.txt")

# Directory for the Report Files
report_dir = os.path.join(os.path.dirname(__file__), "Reports")

# The Description of the Report File
description = "This report is taking a specified set of data and applies static analysis on it"
