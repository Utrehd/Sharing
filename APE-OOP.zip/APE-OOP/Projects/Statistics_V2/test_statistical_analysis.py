# Date:	 		24.06.2017
# Creator:  	SAM
# Description:	This file is executing unit tests for the statistical_analysis.py functions

import unittest
from lib import statistical_analysis


class TestListFormattingMethod(unittest.TestCase):

	def test_get_mean(self):
		# Arrange
		in_list = [20, 40, 0, 60, 80]
		exp_value = 40
		# Act
		out_value = statistical_analysis.get_mean(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_get_median(self):
		# Even Length
		# Arrange
		in_list = [21, 2, 0, 20, 0, 6]  # 0,0,2,6,20,21 Ascending
		exp_value = 4
		# Act
		out_value = statistical_analysis.get_median(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

		# Uneven Length
		in_list = [2, 4, 1, 99, 3]  # 1,2,3,4,99 Ascending
		exp_value = 3
		# Act
		out_value = statistical_analysis.get_median(in_list)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_get_deviation(self):
		# Arrange
		in_list = [5, 6, 8, 4, 10, 3]
		in_value = 6
		exp_value = 2.38
		# Act
		out_value = statistical_analysis.get_overall_deviation(in_list, in_value)
		# Assert
		self.assertEqual(out_value, exp_value)

	def test_get_modes(self):
		# Test 1
		# Arrange
		in_list = [3, 3, 2, 2, 2, 3, 41, 1, 1, 1, 4, 4, 7, 7, 7, 4, 4]
		exp_modes = [4]  # [2, 3, 1, 7]
		# Act
		out_modes = statistical_analysis.get_modes(in_list)
		# Assert
		self.assertEqual(out_modes, exp_modes)

		# Test 2
		# Arrange
		in_list = [3, 3, 2, 2, 2, 3, 41, 1, 1, 1, 4, 4, 7, 7, 7]
		exp_modes = [2, 3, 1, 7]
		# Act
		out_modes = statistical_analysis.get_modes(in_list)
		# Assert
		self.assertEqual(out_modes, exp_modes)

	def test_get_range(self):
		# Arrange
		in_list = [-20, 30, 10, 90]
		exp_range = 110
		# Act
		out_range = statistical_analysis.get_range(in_list)
		# Assert
		self.assertEqual(out_range, exp_range)


if __name__ == '__main__':
	unittest.main()
