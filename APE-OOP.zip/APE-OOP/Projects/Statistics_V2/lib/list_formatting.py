"""
Date:	 		18.06.2017
Creator:  		SAM
Description:
This Module contains several methods for manipulating a list. It was Created in order to provide sufficient support for
statistical analysis.
"""
from typing import List, Any


# Removes one string from each member of the list; Type: STRING
def strip(_list: List[str], target_string: str) -> List[str]:
	"""
	Allows you to strip a target string from each member in a list.

	:param _list: Target list from which you want to strip
	:param target_string: Containing the target string for stripping
	:return: stripped list of the target string
	"""
	# Create new list.
	in_list = list(_list)
	stripped_list = []
	for index, member in enumerate(in_list):
		member = member.strip(target_string)
		stripped_list.append(member)
	return stripped_list


# Sorts a list ascending
def sort_ascending(_list: List[int]) -> List[int]:
	"""
	Returns a list sorted in ascending manner, on the basis of the input list.

	:param _list: Basis for sorted list.
	:return: New sorted list.
	"""
	# Create new list.
	in_list = list(_list)
	sorted_list = []
	# So long the length is bigger than zero.
	while 0 < len(in_list):
		# Get the smallest members of the list and add it to the result
		smallest_member = get_smallest_member(in_list)
		smallest_member_frequency = get_frequency_of_member(in_list, smallest_member)
		sorted_list = append_member_repeatedly(sorted_list, smallest_member, smallest_member_frequency)
		# Remove the added member from the input list
		in_list = remove_members(in_list, smallest_member)
	return sorted_list


# Sorts a list descending
def sort_descending(_list: List[int]) -> List[int]:
	"""
	Returns a list sorted in descending manner, on the basis of the input list.

	:param _list: Basis for sorted list.
	:return: New sorted list.
	"""
	# Create new list.
	in_list = list(_list)
	sorted_list = []
	# So long the length is bigger than zero.
	while 0 < len(in_list):
		biggest_member = get_biggest_member(in_list)
		biggest_member_frequency = get_frequency_of_member(in_list, biggest_member)
		sorted_list = append_member_repeatedly(sorted_list, biggest_member, biggest_member_frequency)
		in_list = remove_members(in_list, biggest_member)
	return sorted_list


# Gets the smallest member of an given list
def get_smallest_member(_list: List[int]) -> int:
	"""
	Gets the smallest member of an list.

	:param _list: Target list.
	:return: Value of smallest member.
	"""
	smallest_member = _list[0]
	for member in _list:
		if smallest_member > member:
			smallest_member = member
	return smallest_member


# Gets the biggest member of an given list; INT
def get_biggest_member(_list: List[int]) -> int:
	"""
	Returns the biggest member of an list.

	:param _list: Target list.
	:return: Value of biggest member.
	"""
	biggest_member = _list[0]
	for member in _list:
		if biggest_member < member:
			biggest_member = member
	return biggest_member


# Gets the occurrence/frequency of an member in a list; ALL
def get_frequency_of_member(_list: List[Any], target_member: Any) -> int:
	"""
	Returns the frequency of an target member in a list.

	:param _list: Target list.
	:param target_member: The value of the target member
	:return: Returns the frequency (occurrence) of the target member in the list.
	"""
	count = 0
	for member in _list:
		if member == target_member:
			count += 1
	return count


# Gets the frequency of most frequent member in the list; ALL
def get_highest_frequency(_list: List[Any]) -> int:
	"""
	Gets the frequency of most frequent member in the list.

	:param _list: Target list.
	:return: Highest frequency.
	"""
	# Create new list.
	in_list = list(_list)
	highest_frequency = 0
	for member in in_list:
		frequency = get_frequency_of_member(in_list, member)
		if highest_frequency < frequency:
			highest_frequency = frequency
	return highest_frequency


# Gets all members which occur in the given frequency; ALL
def get_all_members_occurring_with_frequency(_list: List[Any], target_frequency: int) -> List[Any]:
	"""
	Get a list containing all members occurring with the target frequency in the target list.

	:param _list: Target list.
	:param target_frequency: The value of the target member
	:return: Returns a list containing all members with the target frequency.
	"""
	# Create new list.
	in_list = list(_list)
	members = []
	for member in in_list:
		member_frequency = get_frequency_of_member(in_list, member)
		if target_frequency == member_frequency:
			members.append(member)
	return members


# set frequency of list to x for each member
def limit_max_member_frequency(_list: List[Any], max_frequency: int) -> List[Any]:
	"""
	Creates a new list which does not contain any members with a higher frequency than defined.
	That means that the frequency of members which are higher than max will be removed
	until their frequency is the same as the given max.

	:param _list: Target list.
	:param max_frequency: The maximal frequency allowed in the list
	:return: Returns the reduced list.
	"""
	# Create new list.
	in_list = list(_list)
	out_list = []
	# So long the list has members
	while len(in_list) > 0:
		# if the defined max frequency is bigger or equal of the current frequency add the member to the out lis
		if max_frequency >= get_frequency_of_member(in_list, in_list[0]):
			out_list.append(in_list[0])
		# Remove Member from in_list
		in_list.pop(0)
	return out_list


# Gets the sum of all members in a list
def get_sum(_list: List[int]) -> int:
	"""
	Get the sum of all list members.

	:param _list:
	:return: Sum of all list members.
	"""
	count = 0
	for member in _list:
		count += member
	return count


# Checks of the length of a list is even, if so return true
def check_evenness_of_length(_list: List[Any]) -> bool:
	"""
	Checks if the length of the list is even or not.

	:param _list: The target list
	:return: if length is even = True, if uneven = False
	"""
	modulo = len(_list) % 2
	if modulo == 0:
		return True
	return False


# Will remove all members with a specific value from the list
def remove_members(_list: List[Any], target_member) -> List[Any]:
	"""
	Removes all members with the value of the target member from the list.

	:param _list: Input list.
	:param target_member: The target member which has to be removed.
	:return: Copy of input list without specified members
	"""
	# Create new list.
	in_list = list(_list)
	# Remove all members with the value
	for member in range(_list.count(target_member)):
		in_list.remove(target_member)
	return in_list


# Will append several members by a specific amount to a given list
def append_member_repeatedly(_list: List[Any], member: Any, target_amount: int) -> List[Any]:
	"""
	This method returns a copy of the _list + appended specified member in specified amount

	:param _list: The target list
	:param member: The member which has to be appended
	:param target_amount: The amount of appendications
	:return: target list with append member x
	"""
	# Create new list.
	in_list = list(_list)
	for amount in range(target_amount):
		in_list.append(member)
	return in_list


# Convert each member of the list into int
def convert_to_int(_list: List[Any]) -> List[int]:
	"""
	Returns a list containing the target list members in int format.

	:param _list: target list
	:return: target list in int format
	"""
	in_list = []
	for member in _list:
		in_list.append(int(member))
	return in_list


# Get deviation for each single member based on a target value
def get_deviations_of_members(_list: List[int], target_value: int) -> List[int]:
	"""
	Get a list containing the deviation of each member regarding a given target value

	:param _list: Target List
	:param target_value: Indicates the Value from which each deviation is calculated from.
	:return: List of deviations
	"""
	# Create new list
	in_list = list(_list)
	out_list = []
	for member in in_list:
		# Calculated deviation and append to output list
		deviation = member - target_value
		out_list.append(int(deviation))
	return out_list


# Exponentiate each member of a list
def exponentiate_members(_list: List[int], exponent: int) -> List[int]:
	"""
	Create a list containing the products of an exponentiation with each member given list as base and defined exponent.

	:param _list: Target list contains the bases
	:param exponent: Exponent
	:return: List of all products exponentiation by the exponent
	"""
	# Create new list
	in_list = list(_list)
	out_list = []
	for member in in_list:
		# Create
		product = int(member ** exponent)
		out_list.append(product)
	return out_list
