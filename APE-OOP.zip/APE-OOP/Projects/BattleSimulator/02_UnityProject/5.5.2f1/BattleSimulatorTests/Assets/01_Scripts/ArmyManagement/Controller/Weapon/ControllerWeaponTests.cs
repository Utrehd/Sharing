﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    [TestClass()]
    public class ControllerWeaponTests
    {
        [TestMethod()]
        public void getWeaponTypetest()
        {
            int ID = 6999;

            int res = ID / 1000;
            Assert.AreEqual(6, res);
        }
    }
}