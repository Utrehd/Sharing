﻿/**
 * Autor: David Geisser
 * Start Date: 30.04.2017
 * Last Update: 30.04.2017
 * 
 * Task of this File:
 * Interface of Blacksmith
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class IBlacksmith : _IBuildings
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************

    public Text tagSell;
    public Text textSell;

    private ViewBlacksmith vBlacksmith;
    //private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewBlacksmith arg)
    {
        vBlacksmith = arg;
        // Assign Reference to Parent
        AssignReferences(arg);
        //viewAssigned = true;
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void UpgradeBlacksmith()
    {
        vBlacksmith.UpgradeBlacksmith();
    }
}
