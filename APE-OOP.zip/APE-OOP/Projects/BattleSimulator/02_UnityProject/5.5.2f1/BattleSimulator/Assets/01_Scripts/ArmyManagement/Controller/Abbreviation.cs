﻿// Autor: Samuel Marti
// Start Date: 01.02.2017
// 
// Task of this File:
// Abbrivations for children classes easier to identify.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Global;



public class Abbreviation
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    
    //protected static Application App { get { return Application.App; } }
}

