﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Global
{
    public partial class Language
    {
        /// <summary>
        /// The Languages Keys, You need to add an new key in order to add a new language
        /// </summary>
        public static class LanguageKey
        {
            public const string        // Init the Language Keys
                German = "DE",
                English = "EN";
        }
    }
}
