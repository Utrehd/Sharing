﻿/**
 * Autor: David Geisser
 * Start Date: 12.05.2017
 * Last Update: 12.05.2017
 * 
 * Task of this File:
 * Controller for weapons
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Global;

public class ControllerBattle : _ControllerMaster
{
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerBattle(Application arg) : base(arg) { }

    //--------------------------
    // Public
    //--------------------------

    //ADD Battle Funktions here
}
