﻿/**
 * Autor: David Geisser
 * Start Date: 05.05.2017
 * Last Update: 05.05.2017
 * 
 * Task of this File:
 * Interface of Battle Button
 * I didn't use the IBuilding class as parent, because we don't need the upgrade functions/ variables
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class IBattleButton : _IMaster
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    public GameObject Panel;
    public Text textClose;
    public Text textTitle;
    public Text textDescription;
    public Text textStartBtn;

    private ViewBattleButton vBattleButton;
    //private bool viewAssigned;

    //********************************************************************************************
    // Constructor
    //********************************************************************************************

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewBattleButton arg)
    {
        vBattleButton = arg;
    }
    public void ActivatePanelAction()
    {
        vBattleButton.ActivatePanel();
    }

    public void DeactivatePanelAction()
    {
        vBattleButton.DeactivatePanel();
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void GoToBattle()
    {
        vBattleButton.GoToBattle();
    }
}
