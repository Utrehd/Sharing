﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * Last Update: 29.04.2017 
 * Add Text Training Ground
 * 
 * Task of this File:
 * Commenting Example
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Global
{
    public partial class Language
    {
        /// <summary>
        /// Constuctor, The texts are Initiaded here.
        /// </summary>
        public Language()
        {
            Dictionary = new TranslateDictionary<string, TranslateDictionary<string, string>>();

            // Expirience
            Dictionary[LanguageKey.German][TextKey.Experience] = "Erf";
            Dictionary[LanguageKey.English][TextKey.Experience] = "Exp";

            // Gold Symbol
            Dictionary[LanguageKey.German][TextKey.GoldSymbol] = "EUR";         //I think we don't need different symbols for gold, everyone will know what $ is ;-) DAV
            Dictionary[LanguageKey.English][TextKey.GoldSymbol] = "$";

            // Settings
            Dictionary[LanguageKey.German][TextKey.Settings] = "Einstellungen";
            Dictionary[LanguageKey.English][TextKey.Settings] = "Settings";

            Dictionary[LanguageKey.German][TextKey.Level] = "Stufe:";
            Dictionary[LanguageKey.English][TextKey.Level] = "Level:";

            Dictionary[LanguageKey.German][TextKey.Cost] = "Kosten:";
            Dictionary[LanguageKey.English][TextKey.Cost] = "Costs:";

            // Tent Texts
            // Title
            Dictionary[LanguageKey.German][TextKey.TentTitle] = "Zelte";
            Dictionary[LanguageKey.English][TextKey.TentTitle] = "Tents";

            // Description
            Dictionary[LanguageKey.German][TextKey.TentDescription] = "Jeder Deiner Soldaten braucht einen Platz zum Schlafen";
            Dictionary[LanguageKey.English][TextKey.TentDescription] = "Each single Soldier of your Army needs a place to sleep";

            // Close Button
            Dictionary[LanguageKey.German][TextKey.Close] = "Schliessen";
            Dictionary[LanguageKey.English][TextKey.Close] = "Close";

            // Start
            Dictionary[LanguageKey.German][TextKey.Start] = "Start";
            Dictionary[LanguageKey.English][TextKey.Start] = "Start";

            // Upgrade
            Dictionary[LanguageKey.German][TextKey.Upgrade] = "Aufwerten";
            Dictionary[LanguageKey.English][TextKey.Upgrade] = "Upgrade";       

            // Buy
            Dictionary[LanguageKey.German][TextKey.Buy] = "Kaufen";             
            Dictionary[LanguageKey.English][TextKey.Buy] = "Buy";

            // Places
            Dictionary[LanguageKey.German][TextKey.TentPlaces] = "Benutzte Plätze / Maximum:";
            Dictionary[LanguageKey.English][TextKey.TentPlaces] = "Used Places / Max:";


            // RECURTING CENTER
            Dictionary[LanguageKey.German][TextKey.RecCAvaiableRecruts] = "Verfügbare Rekruten:";
            Dictionary[LanguageKey.English][TextKey.RecCAvaiableRecruts] = "Avaiable Recruts:";

            Dictionary[LanguageKey.German][TextKey.RecCDescription] = "Für eine Armee muss man Frischfleisch anheuern. Nach jeder Schlacht findet man ein paar neue.";
            Dictionary[LanguageKey.English][TextKey.RecCDescription] = "For a army you need to get fresh meat regularly. After each Battle you will find some poor ones.";

            Dictionary[LanguageKey.German][TextKey.RecCNextLevelRec] = "Nächstes Level:";
            Dictionary[LanguageKey.English][TextKey.RecCNextLevelRec] = "Next Level:";

            Dictionary[LanguageKey.German][TextKey.RecCRecPerBattle] = "Rekruten pro Schlacht:";
            Dictionary[LanguageKey.English][TextKey.RecCRecPerBattle] = "Recurts per Battle:";

            Dictionary[LanguageKey.German][TextKey.RecCTitle] = "Rekrutierungs Zentrum";
            Dictionary[LanguageKey.English][TextKey.RecCTitle] = "Recurting Center";

            Dictionary[LanguageKey.German][TextKey.RecCHire] = "Rekrutieren";
            Dictionary[LanguageKey.English][TextKey.RecCHire] = "Recrut";

            //Training Ground
            // Title
            Dictionary[LanguageKey.German][TextKey.TrainingGroundTitle] = "Trainingsplätze";
            Dictionary[LanguageKey.English][TextKey.TrainingGroundTitle] = "Training Grounds";

            Dictionary[LanguageKey.German][TextKey.TrainingGroundDescription] = "Auf den Trainingsplätzen können Truppen verbessert werden.";
            Dictionary[LanguageKey.English][TextKey.TrainingGroundDescription] = "Improve your troops on the training grounds";

            Dictionary[LanguageKey.German][TextKey.TrainingGroundExpPerTrain] = "Erfahrung pro Training:";
            Dictionary[LanguageKey.English][TextKey.TrainingGroundExpPerTrain] = "Experience per training:";

            Dictionary[LanguageKey.German][TextKey.TrainingGroundNextLevelExp] = "Erfahrungsplus auf nächster Stufe:";
            Dictionary[LanguageKey.English][TextKey.TrainingGroundNextLevelExp] = "Experience at next level:";

            Dictionary[LanguageKey.German][TextKey.TrainingGroundTrain] = "Trainieren";
            Dictionary[LanguageKey.English][TextKey.TrainingGroundTrain] = "Train";

            // Blacksmith Texts
            // Title
            Dictionary[LanguageKey.German][TextKey.BlacksmithTitle] = "Schmiede";
            Dictionary[LanguageKey.English][TextKey.BlacksmithTitle] = "Blacksmith";

            // Description
            Dictionary[LanguageKey.German][TextKey.BlacksmithDescription] = "Hol dir neue Waffen für deine Armee";
            Dictionary[LanguageKey.English][TextKey.BlacksmithDescription] = "Buy and sell weapons for your army";

            // Sell
            Dictionary[LanguageKey.German][TextKey.BlacksmithSell] = "Rabat";
            Dictionary[LanguageKey.English][TextKey.BlacksmithSell] = "Sell";

            // Battle Subscreen Texts
            // Title
            Dictionary[LanguageKey.German][TextKey.BattleTitle] = "Schlacht";
            Dictionary[LanguageKey.English][TextKey.BattleTitle] = "Battle";

            // Description
            Dictionary[LanguageKey.German][TextKey.BattleDescription] = "Noch ohne Funktion, später Gegner/ Turnier auswählen und welche Soldaten man mitnehmen möchte";
            Dictionary[LanguageKey.English][TextKey.BattleDescription] = "No function yet, later choose enemy and your troops"; 

             //Weapons
             Dictionary[LanguageKey.German][TextKey.Weapon1001] = "Testschwert";
            Dictionary[LanguageKey.English][TextKey.Weapon1001] = "Testsword";

            Dictionary[LanguageKey.German][TextKey.Weapon2001] = "Testspeer";
            Dictionary[LanguageKey.English][TextKey.Weapon2001] = "Testspeer";

            Dictionary[LanguageKey.German][TextKey.Weapon3001] = "Testbogen";
            Dictionary[LanguageKey.English][TextKey.Weapon3001] = "Testbow";

            Dictionary[LanguageKey.German][TextKey.Weapon4001] = "Testkeule";
            Dictionary[LanguageKey.English][TextKey.Weapon4001] = "Testmace";

            Dictionary[LanguageKey.German][TextKey.Weapon5001] = "Testaxt";
            Dictionary[LanguageKey.English][TextKey.Weapon5001] = "Testaxe";

            //Error Messanges
            Dictionary[LanguageKey.German][TextKey.NoGold] = "Nicht genug Gold!";
            Dictionary[LanguageKey.English][TextKey.NoGold] = "Not enough Gold!";


            Dictionary[LanguageKey.German][TextKey.NoPlaces] = "Kein freien Plätz mehr.";
            Dictionary[LanguageKey.English][TextKey.NoPlaces] = "No free Places left";


            Dictionary[LanguageKey.German][TextKey.NoRecruts] = "Kein Rekruten";
            Dictionary[LanguageKey.English][TextKey.NoRecruts] = "No Recruts";

        }
    }
}
