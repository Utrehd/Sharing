﻿/**
 * Autor: David Geisser
 * Start Date: 23.04.2017
 * Last Update: 29.04.2017
 * 
 * Task of this File:
 * Controller for weapons
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Global;

public class ControllerWeapon : _ControllerMaster
    {
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerWeapon(Application arg) : base(arg) { }

    //--------------------------
    // Public
    //--------------------------

    public int getWeaponType(int ID)
    {
        return ID / 1000;   //ID has the format AXXX and A is the weapon type, by div with 1000 in the int format the return is just the A value the rest is cuted
    }

    public string getTextKey(int ID)
    {
        return "Weapon" + ID.ToString();    //to writte the name of a weapon, you can generate the textkey with this function and the ID of the weapon
    }
}

