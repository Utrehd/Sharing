﻿// Autor: Samuel Marti
// Start Date: 26.02.2017
// 
// Task of this File:
// Instantiate all the Game

#region Libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Global;
#endregion

[System.Serializable]
public class ISubscreen : System.Object
{
    //********************************************************************************************
    // Var Declaration
    //********************************************************************************************
    #region Declarations
    //--------------------------
    // Public Texts
    //--------------------------
    public Text textClose;
    public Text textLevel;
    public Text textUpgrade;
    public Text textUpgradeCost;
    public Text tagUpgradeCost;
    public Text tagLevel;
    public Text textTitle;
    public Text textDescription;

    //--------------------------
    // Variables
    //--------------------------
    [HideInInspector]
    public string keyTitle;
    [HideInInspector]
    public string keyDescription;
    [HideInInspector]
    public _Buildings building;
    #endregion
}

