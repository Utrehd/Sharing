﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    public class _ControllerMaster
    {
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    protected Application app;

    public _ControllerMaster(Application arg)
    {
        app = arg;
    }
}

