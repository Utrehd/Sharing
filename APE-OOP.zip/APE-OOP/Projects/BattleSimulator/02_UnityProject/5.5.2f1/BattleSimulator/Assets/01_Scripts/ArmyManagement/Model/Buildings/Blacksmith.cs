﻿/**
 * Autor: David Geisser
 * Start Date: 29.04.2017
 * Last Update: 29.04.2017
 * 
 * Task of this File:
 * Model of Blacksmith
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blacksmith : _Buildings
{
    /// <summary>
    /// Blacksmith Constructor, is called automatic when new Blacksmith object generated.
    /// </summary>
    public Blacksmith() //Default Constructor Blacksmith
    {
        SellPerLevel = 5;   //Set Blacksmith Varaibles to Start Value -> Later: Load from SaveData
        Costs = 2;
        UpgradeModificator = 150;
        Level = 1;
        MaxLevelBuilding = 15;
    }

    /// <summary>
    /// The value of how much the weapons get cheaper per level
    /// </summary>
    public int SellPerLevel { get; set; }

    /// <summary>
    /// The Total amount of Places
    /// </summary>
    public int Sell
    {
        get
        {
            return Level * SellPerLevel;
        }
    }

}
