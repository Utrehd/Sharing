﻿/**
 * Autor: David Geisser
 * Start Date: 23.04.2017
 * Last Update: 29.04.2017
 * 
 * Task of this File:
 * Model for Weapons
 */

 //probably work with enum
 //http://answers.unity3d.com/questions/513488/c-weapon-class-generation.html

#region Libraries
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#endregion

public class Weapon
{

    #region Constructor
    /// <summary>
    /// Weapon Constructor, is called automatic when new Weapon object generated.
    /// </summary>
    public Weapon() //Default Constructor Weapon
    {
        //Test weapon
        weaponID = 1001;
        damage = 5;
        hitPerSek = 0.8;
        price = 10;
    }

    public Weapon(int ID, int DAM, int HPS, int PRI)
    {
        weaponID = ID;
        damage = DAM;
        hitPerSek = HPS;
        price = PRI;
    }
    #endregion

    /// <summary>
    /// The ID of the weapon -> goto model to see details
    /// </summary>
    /* ID format is TXXX    XXX is indiviadual NR of the Weapon
     * T is the type of the weapon
     * 1: sword
     * 2: speer
     * 3: bow
     * 4: mace (streitkolben)
     * 5: axe
     */
    public int weaponID { get; set; }

    /// <summary>
    /// The damage per hit
    /// </summary>
    public int damage { get; set; }

    /// <summary>
    /// The hit per sek
    /// </summary>
    public double hitPerSek { get; set; }

    /// <summary>
    /// Damage per sek
    /// </summary>
    public double DPS {
        get {
            return damage * hitPerSek;
        }
    }

    /// <summary>
    /// The price of the weapon
    /// </summary>
    public int price { get; set; }

}