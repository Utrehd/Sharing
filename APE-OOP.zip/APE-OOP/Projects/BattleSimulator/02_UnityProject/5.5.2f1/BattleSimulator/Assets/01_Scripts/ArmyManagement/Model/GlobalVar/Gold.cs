﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * The Gold Model
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gold : _ModelMaster
    {

    /// <summary>
    /// Will be Triggered when the Gold is Changing
    /// </summary>
    public event DelegateTrend  EventGoldChanged;

    // Data
    private int _Amount;
    /// <summary>
    /// The Amount of Gold + FireEvent "EventGoldChange"
    /// </summary>
    public int Amount
    {
        get
        {
            return _Amount;
        }
        set
        {
            // Save old Value into temp
            int temp = _Amount;
            // Assign new Value
            _Amount = value;
            // Trigger the smaller bigger event
            TriggerEvent(EventGoldChanged, temp, value);
         }
     }

         /// <summary>
         /// Gold Destructor, is called automatic when new Gold object destroyed.
         /// </summary>
         ~Gold() //Gold Destructor -> Later: Save to SaveData
         {
             //Destructor at the Moment unnessesary, just here for example

             Debug.Log("Destructor"); //Should be shown at end of programm
         }
     }


