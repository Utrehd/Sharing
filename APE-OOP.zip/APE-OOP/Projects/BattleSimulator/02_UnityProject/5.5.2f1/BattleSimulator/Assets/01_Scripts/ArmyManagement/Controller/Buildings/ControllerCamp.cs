﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * The Camp Controller contains the parent rules which are used by all buildings
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Global;

public class ControllerCamp : _ControllerMaster
{
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerCamp(Application arg) : base(arg) { }
    //--------------------------
    // Public
    //--------------------------
    /// <summary>
    /// Pay Costs
    /// </summary>
    /// <param name="give costs of object costs"></param>
    protected void TryToUpgrade(_Buildings building)        //use reference 
    {
        if (EnoughGoldForCost(building.Costs))
        {
            PayUpgradeCosts(ref building);
            IncreaseCosts(ref building);
            IncrementLevel(ref building);
        }
    }

    //--------------------------
    // Protected
    //--------------------------
    protected bool EnoughGoldForCost(double costs)
    {
        if (app.mGold.Amount >= costs)
        {
            return true;
        }
        else
        {
            //EventManager.CallPopup(Language.TextKey.NoGold);
            return false;
        }
    }

    protected void Pay(int cost)
    {
        app.mGold.Amount = app.mGold.Amount - cost;
    }

    //--------------------------
    // Private
    //--------------------------
    #region Private
    private void PayUpgradeCosts(ref _Buildings building)
    {
        app.mGold.Amount = app.mGold.Amount - Convert.ToInt32(building.Costs);
    }
    private void IncreaseCosts(ref _Buildings building)
    {
        building.Costs = (building.Costs / 100) * building.UpgradeModificator;
    }
    private void IncrementLevel(ref _Buildings building)
    {
        building.Level++;
    }
    #endregion
}