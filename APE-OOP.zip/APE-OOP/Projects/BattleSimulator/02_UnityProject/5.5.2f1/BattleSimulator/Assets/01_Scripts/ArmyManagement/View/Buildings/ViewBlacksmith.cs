﻿/**
 * Autor: David Geisser
 * Start Date: 29.04.2017
 * Last Update: 29.04.2017
 * 
 * Task of this File:
 * The Blacksmith View
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
using System;
using TextKey = Global.Language.TextKey;

public class ViewBlacksmith : _ViewBuildings
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    //private ViewSubscreen subscreen;


    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    public ViewBlacksmith(Application arg, _IBuildings arg2, _Buildings arg3, string title, string description) : base(arg,ref arg2, ref arg3, title, description)
    {
        // Assign Subscreen

        //subscreen = new ViewSubscreen(app.iTent.ISubscreenReferences);
        //subscreen.AssignData
        //(
        //   app.mTents,
        //  TextKey.TentTitle,
        // TextKey.TentDescription
        //);
        DeactivatePanel();
        UpdateAll();

    }

    #region Buttons
    public void UpgradeBlacksmith()
    {
        app.cBlacksmith.UpgradeBlacksmith();
        UpdateAll();    
    }
    #endregion

    #region Update Functions
    override public void UpdateAll()
    {
        //Parent
        UpdateAllGeneralTags();
        UpdateAllGeneralTexts();

        //This
        UpdateTagSell();
        UpdateTextSell();

    }

    // UPDATE TAG METOHEDS
    private void UpdateTagSell()
    {
        Methods.AssignVariableToTag(app.mBlacksmith.Sell, app.iBlacksmith.tagSell);
    }

    // UPDATE TEXT METOHDES
    private void UpdateTextSell()
    {
        Methods.AssignTextToTag(Language.TextKey.BlacksmithSell, app.iBlacksmith.textSell);
    }
    #endregion 
}
