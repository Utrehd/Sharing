﻿/**
 * Autor: David Geisser
 * Start Date: 05.05.2017
 * Last Update: 05.05.2017
 * 
 * Task of this File:
 * View of Battle Button
 * I didn't use the ViewBuilding class as parent, because we don't need the upgrade functions/ variables
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
using System;
using TextKey = Global.Language.TextKey;

public class ViewBattleButton : _ViewMaster
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    //private ViewSubscreen subscreen;
    private IBattleButton iBattleButton;
    private string keyTitle;
    private string keyDescription;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    public ViewBattleButton(Application arg, ref IBattleButton arg2, string title, string description) : base(ref arg)
    {
        // Assign Subscreen
        iBattleButton = arg2;
        keyTitle = title;
        keyDescription = description;
        DeactivatePanel();
        UpdateAll();

        // Add function to event manager
        EventManager.DeactivateAllPanels += this.DeactivatePanel;

    }

    // Click Function
    public void ActivatePanel()
    {
        EventManager.CallDeactivateAllPanels();
        iBattleButton.Panel.SetActive(true);
        UpdateAll();
    }

    public void DeactivatePanel()
    {
        iBattleButton.Panel.SetActive(false);
        UpdateAll();
    }

    #region Buttons
    public void GoToBattle()
    {
        app.cBattleButton.GoToBattle();
    }
    #endregion

    #region Update Functions
    public void UpdateAll()
    {
        //This Update
        // Description
        Methods.AssignTextToTag(keyTitle, iBattleButton.textTitle);
        // Title
        Methods.AssignTextToTag(keyDescription, iBattleButton.textDescription);
        // Close
        Methods.AssignTextToTag(Language.TextKey.Close, iBattleButton.textClose);
        // Close
        Methods.AssignTextToTag(Language.TextKey.Start, iBattleButton.textStartBtn);

    }

    // UPDATE TAG METOHEDS


    // UPDATE TEXT METOHDES

    #endregion 
}
