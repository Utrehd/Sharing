﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * The Tent Model
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tents :  _Buildings
{
    public event DelegateTrend EventPlacesChanged;
    /// <summary>
    /// Tents Constructor, is called automatic when new Tents object generated.
    /// </summary>

    /// <summary>
    /// The Places you have per level
    /// </summary>
    public int PlacesPerTent{ get; set; } //could we make it a const???

    /// <summary>
    /// The Numeric Places Offset
    /// </summary>
    public int PlacesOffset { get; set; } //could we make it a const???

    private int _Places;
    /// <summary>
    /// The Total amount of Places
    /// </summary>
    public int Places
    {
        get
        {
            return _Places;
        }
        set
        {
            // Save old Value into temp
            int temp = _Places;
            // Assign new Value
            _Places = value;
            // Trigger the Change Event
            TriggerEvent(EventPlacesChanged, temp, value);
        }
    }
}
