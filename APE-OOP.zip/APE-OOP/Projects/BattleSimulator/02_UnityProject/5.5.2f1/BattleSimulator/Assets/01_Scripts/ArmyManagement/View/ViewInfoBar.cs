﻿/**
 * Autor: David Geisser & Samuel
 * Start Date: 29.05.2017
 * 
 * Task of this File:
 * Manage the update of the text gui from the Infobar
 * This whole class was remodel in a event driven manner
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Global;

public class ViewInfoBar : _ViewMaster
{
    //--------------------------
    // Constructor
    //--------------------------
    public ViewInfoBar(Application arg) : base(ref arg)
    {
        // Assign Events Gold Tag to Gold Changed
        app.mGold.EventGoldChanged += TagGoldUpdate;
        app.mExperience.EventExpChanged += TagExpUpdate;
        app.mTents.EventPlacesChanged += TagPlacesUpdate;
        app.mTroops.EventTroopsAmountChanged += TagTroopsUpdate;
    }
    public void TagTroopsUpdate(string changeTrend)
    {
        string amount = app.mTroops.Amount.ToString();
        app.iInfoBar.ArmyText.text = amount;

        // Run Animation
        CallAnimationSmallerBigger(app.iInfoBar.ArmyText, changeTrend);
    }

    public void TagPlacesUpdate(string changeTrend)
    {
        //Put the Number of Man Variable and the Max Number of Man in a String and seperate them with
        string places = app.mTents.Places.ToString();
        app.iInfoBar.ArmyPlaces.text = places;

        CallAnimationSmallerBigger(app.iInfoBar.ArmyPlaces, changeTrend);
    }

    public void TagExpUpdate(string changeTrend)
    {
        // Assign vars
        string Exp = app.mExperience.AmountExp.ToString();
        app.iInfoBar.ExpText.text = Exp;

        // Run Animation
        CallAnimationSmallerBigger(app.iInfoBar.ExpText, changeTrend);
    }

    public void TagGoldUpdate(string changeTrend)
    {
        // Assign vars
        string Money = app.mGold.Amount.ToString();
        app.iInfoBar.MoneyText.text = Money;

        // Run Animation
        CallAnimationSmallerBigger(app.iInfoBar.MoneyText, changeTrend);
    }
}
