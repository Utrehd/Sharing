﻿// Autor: Samuel Marti & David Geisser
// Start Date: 01.02.2017
// Last Update: 12.05.2017
//                                  -> Some lines are just here for testing
// Task of this File:
// Instantiate all the Game

#region Libraries
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
#endregion

[System.Serializable]
public class Application : MonoBehaviour
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    #region Intantiate Classes

    //--------------------------
    // Models
    //--------------------------
    
    public Gold mGold;
    public Troops mTroops;
    public Experience mExperience;

    public Tents mTents;
    public RecrutingCenter mRecrutingCenter;
    public TrainingGround mTrainingGround;
    public Blacksmith mBlacksmith;

    //--------------------------
    // View
    //--------------------------
    public ViewRecrutingCenter vRecrutingCenter;
    public ViewTents vTents;
    public ViewTrainingGround vTrainingGround;
    public ViewBlacksmith vBlacksmith;
    public ViewBattleButton vBattleButton;

    public ViewBattle vBattle;
    public ViewPopup vPopup;
    public ViewInfoBar vInfoBar;

    public VTesting vTesting; //Just needed for testing

    //--------------------------
    // Controller
    //--------------------------
    public ControllerRecrutingCenter cRecrutingCenter;
    public ControllerTents cTents;
    public ControllerTrainingGround cTrainingGround;
    public ControllerBlacksmith cBlacksmith;
    public ControllerBattleButton cBattleButton;
    public ControllerBattle cBattle;
    #endregion

    //--------------------------
    // Interface Assignment
    //--------------------------
    public ITent iTent;
    public IRecrutingCenter iRecrutingCenter;
    public ITrainingGround iTrainingGround;
    public IBlacksmith iBlacksmith;
    public IBattleButton iBattleButton;

    public IBattle iBattle;
    public IPopup iPopup;
    public IInfoBar iInfoBar;

    public ITesting iTesting; //Just needed for testing

    //********************************************************************************************
    // Constructor, All setting for the game need to defined here. Values need to be assigned.
    //********************************************************************************************
    #region Constructor
    public void Start()
    {
        // Set Language
        Language.Instance.SetToEnglish();

        //----------------------
        // Init Instances
        //----------------------
        InitModels();
        InitControllers();
        InitViews();     
        AssignViewsToInterfaces();
        InitSettings();

        // Assign Events
        EventManager.EventBattleEndedController += cRecrutingCenter.AddRecruts;
        EventManager.EventBattleStart += InitBattle;

    }
    #endregion



    private void InitModels()
    {
        mTroops = new Troops();
        mGold = new Gold();
        mExperience = new Experience();

        mRecrutingCenter = new RecrutingCenter();
        mTents = new Tents();
        mTrainingGround = new TrainingGround();
        mBlacksmith = new Blacksmith();
    } 

    private void InitControllers()
    {
        cRecrutingCenter = new ControllerRecrutingCenter(this);
        cTents = new ControllerTents(this);
        cTrainingGround = new ControllerTrainingGround(this);
        cBlacksmith = new ControllerBlacksmith(this);
        cBattleButton = new ControllerBattleButton(this);
    }

    private void InitViews()
    {
        vRecrutingCenter = new ViewRecrutingCenter(this, iRecrutingCenter, mRecrutingCenter, Language.TextKey.RecCTitle, Language.TextKey.RecCDescription);
        vTents = new ViewTents(this, iTent, mTents, Language.TextKey.TentTitle, Language.TextKey.TentDescription);
      //  vTrainingGround = new ViewTrainingGround(this, iTrainingGround, mTrainingGround, Language.TextKey.TrainingGroundTitle, Language.TextKey.TrainingGroundDescription);
      //  vBlacksmith = new ViewBlacksmith(this, iBlacksmith, mBlacksmith, Language.TextKey.BlacksmithTitle, Language.TextKey.BlacksmithDescription);
        vBattleButton = new ViewBattleButton(this, ref iBattleButton, Language.TextKey.BattleTitle, Language.TextKey.BattleDescription);

        vBattle = new ViewBattle(this);
      //  vPopup = new ViewPopup(this);
        vInfoBar = new ViewInfoBar(this);

        vTesting = new VTesting(this); //Just needed for testing
    }

    private void AssignViewsToInterfaces()
    {
        iRecrutingCenter.AssignView(ref vRecrutingCenter);  //pass objects by reference not by value, when possible
      //  iTrainingGround.AssignView(ref vTrainingGround);
      //  iBlacksmith.AssignView(ref vBlacksmith);
        iTent.AssignView(ref vTents);
        iBattleButton.AssignView(ref vBattleButton);

        iBattle.AssignView(ref vBattle);
      //  iPopup.AssignView(ref vPopup);
        iInfoBar.AssignView(ref vInfoBar);

        iTesting.AssignView(vTesting); //Just needed for testing
    }

    private void InitBattle()   //Init when in Battle screen
    {
        cBattle = new ControllerBattle(this);
    }

    private void InitSettings()
    {
        //General
        mGold.Amount = 20;
        mExperience.AmountExp = 0;
        mTroops.Amount = 10;

        //Tents
        mTents.PlacesPerTent = 8;   //Set Tents Varaibles to Start Value -> Later: Load from SaveData
        mTents.Costs = 2;
        mTents.UpgradeModificator = 150;
        mTents.Level = 1;
        mTents.Places = 10;

        
    }
}
