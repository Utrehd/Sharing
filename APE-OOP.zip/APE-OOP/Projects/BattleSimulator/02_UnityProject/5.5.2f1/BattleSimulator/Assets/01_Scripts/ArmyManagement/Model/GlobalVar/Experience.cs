﻿/**
 * Autor: David Geisser
 * Start Date: 14.04.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * Model for Experience
 */

#region Libraries
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#endregion

    public class Experience : _ModelMaster
    {

    public event DelegateTrend EventExpChanged;

    #region Constructor
    /// <summary>
    /// Experience Constructor, is called automatic when new Experience object generated.
    /// </summary>
    public Experience() //Default Constructor Experience
    {
        AmountExp = 0;  //Set Experience value to Start Value -> Later: Load from SaveData
    }
    #endregion

    private int _AmountExp;
    /// <summary>
    /// The Amount of Experience
    /// </summary>
    public int AmountExp
    {
        get
        {
            return _AmountExp;
        }
        set
        {
            // Save old Value into temp
            int temp = _AmountExp;
            // Assign new Value
            _AmountExp = value;
            // Trigger the smaller bigger event
            TriggerEvent(EventExpChanged, temp, value);
        }
    }

}