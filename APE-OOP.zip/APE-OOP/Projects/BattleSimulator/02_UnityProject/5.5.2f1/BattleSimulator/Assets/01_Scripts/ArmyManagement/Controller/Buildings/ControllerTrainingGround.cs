﻿/**
 * Autor: David Geisser
 * Start Date: 15.04.2017
 * Last Update: 15.04.2017
 * 
 * Task of this File:
 * This Controller controls the Training Ground rules
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;

public class ControllerTrainingGround : ControllerCamp
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerTrainingGround(Application arg) : base(arg) { }
    //--------------------------
    // Public
    //--------------------------
    #region Public
    public void UpgradeTrainingGround()
    {
        TryToUpgrade(app.mTrainingGround);
    }

    public void Train()
    {
        if (EnoughGoldForCost(app.mTrainingGround.TrainCostTotal))
        {
            Pay(app.mTrainingGround.TrainCostTotal);
            AddExp();
        }
    }
    #endregion
    //--------------------------
    // Private
    //--------------------------
    #region Private
    private void AddExp()
    {
        app.mExperience.AmountExp += app.mTrainingGround.ExpPerTrain;
    }
    #endregion
}