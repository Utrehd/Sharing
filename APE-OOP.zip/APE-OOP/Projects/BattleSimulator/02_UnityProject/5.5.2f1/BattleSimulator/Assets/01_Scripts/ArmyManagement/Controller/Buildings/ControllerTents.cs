﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * This Controller controls the Tent Rules
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;

public class ControllerTents : ControllerCamp
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************

    //--------------------------
    // Properties
    //--------------------------
    public int LeftPlaces
    {
        get
        {
            return app.mTents.Places - app.mTroops.Amount;
        }
    }
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerTents(Application arg) : base(arg){ }
    //--------------------------
    // Public
    //--------------------------

    public void UpgradeTentAction()
    {
        TryToUpgrade(app.mTents);
        CalculatePlaces();
    }

    //--------------------------
    // Private
    //--------------------------
    private void CalculatePlaces()
    {
        app.mTents.Places = app.mTents.Level * app.mTents.PlacesPerTent + app.mTents.PlacesOffset;
    }
}
