﻿/**
 * Autor: David Geisser
 * Start Date: 05.05.2017
 * Last Update: 05.05.2017
 * 
 * Task of this File:
 * Controller of Battle Button
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;

public class ControllerBattleButton : _ControllerMaster
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerBattleButton(Application arg) : base(arg) { }
    //--------------------------
    // Public
    //--------------------------
    #region Public

    public void GoToBattle()
    {
        EventManager.CallBattleStart();
        Debug.Log("change scene here");
        app.iBattle.ActivateAction();
    }

    #endregion
    //--------------------------
    // Private
    //--------------------------
    #region Private

    #endregion
}