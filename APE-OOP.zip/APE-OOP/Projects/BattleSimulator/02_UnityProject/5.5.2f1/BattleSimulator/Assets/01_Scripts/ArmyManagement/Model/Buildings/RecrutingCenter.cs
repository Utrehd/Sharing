﻿// Autor: Samuel Marti & David Geisser 
// Start Date: 01.02.2017
// Last Update: 17.04.2017
// 
// Task of this File:
// The Recrut Center Model

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;



public class RecrutingCenter : _Buildings
{

    /// <summary>
    /// RC Constructor, is called automatic when new RC object generated.
    /// </summary>
    public RecrutingCenter() //Default Constructor RC
    {
        RecrutsPerBattleBase = 2;   //Set RC Varaibles to Start Value -> Later: Load from SaveData
        Costs = 5;
        UpgradeModificator = 200;
        Level = 1;
        CostPerRecrut = 1;
    }

    /// <summary>
    /// The Aviable Recruts
    /// </summary>
    public int AvaiableRecruts { get; set; }

    /// <summary>
    /// The Recruts you receive Per battle
    /// </summary>
    public int RecrutsPerBattle
    {
        get
        {
            return RecrutsPerBattleBase * Level;
        }
    }

    /// <summary>
    /// Cost per single recrut
    /// </summary>
    public int CostPerRecrut { get; set; }

    /// <summary>
    /// The total cost of recruting all recruts
    /// </summary>
    public int AvaiableRecrutsCostTotal {
        get
        {
            return AvaiableRecruts * CostPerRecrut;
        }
    }

    /// <summary>
    /// The Amount of recruts per battle in the next level of the building
    /// </summary>
    public int NextLevelRecrutsPerBattle
    {
        get
        {
            return RecrutsPerBattleBase * (Level + 1);
        }
    }

    /// <summary>
    /// The RecrutsPerBattle Base number
    /// </summary>
    public int RecrutsPerBattleBase { get; set; }

    /// <summary>
    /// The Number of Recruts to user wants to recrut
    /// </summary>
    public int UserNrOfRecruts { get; set;}

    /// <summary>
    /// The total cost of recruting all recruts the user wants
    /// </summary>
    public int UserCostRecrut
    {
        get
        {
            return UserNrOfRecruts * CostPerRecrut;
        }
    }

}

