﻿/**
 * Autor: David Geisser
 * Start Date: 15.04.2017
 * Last Update: 15.04.2017
 * 
 * Task of this File:
 * The Training Ground View
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
using System;
using TextKey = Global.Language.TextKey;
using UnityEditor;


public class ViewTrainingGround : _ViewBuildings
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    //private ViewSubscreen subscreen;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ViewTrainingGround(Application arg, _IBuildings arg2, _Buildings arg3, string title, string description) : base(arg, ref arg2, ref arg3, title, description)
    {
        // Assign Subscreen Data to Subscreen
        // subscreen = new ViewSubscreen(app.iRecrutingCenter.ISubscreenReferences);
        // Create Subscreen Data
        // subscreen.AssignData(app.mRecrutingCenter,
        // TextKey.RecCTitle,
        // TextKey.RecCDescription);


        DeactivatePanel();
        UpdateAll();
    }

    #region Buttons
    public void UpgradeTrainingGround()
    {
        app.cTrainingGround.UpgradeTrainingGround();
        UpdateAll();
    }
    public void Train()
    {
        app.cTrainingGround.Train();
        UpdateAll();
    }
    #endregion

    override public void UpdateAll()
    {
        //Parent
        UpdateAllGeneralTags();
        UpdateAllGeneralTexts();
        //Tags      
        UpdateTagTrainCost();
        UpdateTagNextLevelExp();
        UpdateTagExpPerTrain();
        //Texts
        UpdateTextTrainCost();
        UpdateTextNextLevelExp();
        UpdateTextExpPerTrain();

        //buttons
        UpdateButtonTrain();
    }

    #region PRIVATE
    // UPDATE TAG METOHEDS
    private void UpdateTagTrainCost()
    {
        Methods.AssignVariableToTag(app.mTrainingGround.TrainCostTotal, app.iTrainingGround.tagTrainCost);
    }

    private void UpdateTagExpPerTrain()
    {
        Methods.AssignVariableToTag(app.mTrainingGround.ExpPerTrain, app.iTrainingGround.tagExpPerTrain);
    }

    private void UpdateTagNextLevelExp()
    {
        Methods.AssignVariableToTag(app.mTrainingGround.NextLevelExpPerTrain, app.iTrainingGround.tagNextLevelExp);
    }


    // UPDATE TEXT METOHDES
    private void UpdateTextTrainCost()
    {
        Methods.AssignTextToTag(TextKey.Cost, app.iTrainingGround.textTrainCost);
    }

    private void UpdateTextExpPerTrain()
    {
        Methods.AssignTextToTag(TextKey.TrainingGroundExpPerTrain, app.iTrainingGround.textExpPerTrain);
    }

    private void UpdateTextNextLevelExp()
    {
        Methods.AssignTextToTag(TextKey.TrainingGroundNextLevelExp, app.iTrainingGround.textNextLevelExp);
    }
    
    
    private void UpdateButtonTrain()
    {
        Methods.AssignTextToTag(TextKey.TrainingGroundTrain, app.iTrainingGround.buttonTrain);
    }
    #endregion

}
