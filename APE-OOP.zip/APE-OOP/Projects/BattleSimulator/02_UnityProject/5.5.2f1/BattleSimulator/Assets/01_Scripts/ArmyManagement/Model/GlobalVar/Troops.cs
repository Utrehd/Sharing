﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * The Troops Model
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Troops : _ModelMaster
{
    public event DelegateTrend EventTroopsAmountChanged;
    private int _Amount;
    /// <summary>
    /// The total amount of troops in your army
    /// </summary>
    public int Amount
    {
        get
        {
            return _Amount;
        }
            
        set
        {
            // Save old Value into temp
            int temp = _Amount;
            // Assign new Value
            _Amount = value;
            // Trigger the smaller bigger event
            TriggerEvent(EventTroopsAmountChanged, temp, value);
        }
    }
}
