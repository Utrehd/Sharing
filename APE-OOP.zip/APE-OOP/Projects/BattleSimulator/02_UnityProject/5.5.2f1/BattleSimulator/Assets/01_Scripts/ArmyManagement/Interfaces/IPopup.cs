﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class IPopup : MonoBehaviour {
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    public Text textMessage;
    public Text textClose;
    public GameObject popup;

    private ViewPopup vPopup;
    //private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewPopup arg)
    {
        vPopup = arg;
        //viewAssigned = true;
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void DeactivateAction()
    {
        vPopup.DeactivatePopup();
    }
}
