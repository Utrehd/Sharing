﻿#region Libraries
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;
#endregion

public class _ModelMaster
{
    // Creat Delegate
    public delegate void DelegateTrend(string changeTrend);

    protected void TriggerEvent(DelegateTrend _event, int oldValue, int newValue)
    {
        // Trigger the smaller bigger event
        if (_event != null)
        {
            if (newValue == oldValue)
            {
                _event("SAME");
                Debug.Log("Triggered EventGoldChanged SAME");
            }
            else if (newValue < oldValue)
            {
                _event("SMALLER");
                Debug.Log("Triggered EventGoldChanged SMALLER");
            }
            else
            {
                _event("BIGGER");
                Debug.Log("Triggered EventGoldChanged BIGGER");
            }
        }
    }
}
