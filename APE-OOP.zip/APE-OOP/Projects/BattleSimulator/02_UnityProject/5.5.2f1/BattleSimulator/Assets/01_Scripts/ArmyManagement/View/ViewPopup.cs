﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * Calls the popup with defined message
 */

using UnityEngine;
using UnityEditor;
using System.Collections;
using UnityEngine.UI;
using Global;
using TextKey = Global.Language.TextKey;

public class ViewPopup : _ViewMaster
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    //--------------------------
    // Constructor
    //--------------------------
    public ViewPopup(Application arg) : base(ref arg)
    {
        DeactivatePopup();
        //----------------------
        // Add Events
        //----------------------

        EventManager.ErrorPopup += this.Call;
    }

    //--------------------------
    // Public
    //--------------------------

    public void Call(string _key)
    {
        ActivatePopup();
        UpdateTagClose();
        UpdateTagMessage(_key);
    }

    // Click Function
    public void ActivatePopup()
    {
        app.iPopup.popup.SetActive(true);
    }

    public void DeactivatePopup()
    {
        app.iPopup.popup.SetActive(false);
    }

    //--------------------------
    // Private
    //--------------------------

    private void UpdateTagClose()
    {
        Methods.AssignTextToTag(TextKey.Close, app.iPopup.textClose);
    }
    private void UpdateTagMessage(string key)
    {
        Methods.AssignTextToTag(key, app.iPopup.textMessage);
    }
}
