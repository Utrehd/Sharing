﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class ITent : _IBuildings
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************

    public Text tagUsedPlaces;
    public Text tagPlaces;
    public Text textPlaces;
    //public ISubscreen ISubscreenReferences = new ISubscreen();

    private ViewTents vTents;
    //private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewTents arg)
    {
        vTents = arg;
        // Assign Reference to Parent
        AssignReferences(arg);
        //viewAssigned = true;
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void UpgradeTentAction()
    {
        vTents.UpgradeTent();
    }
}
