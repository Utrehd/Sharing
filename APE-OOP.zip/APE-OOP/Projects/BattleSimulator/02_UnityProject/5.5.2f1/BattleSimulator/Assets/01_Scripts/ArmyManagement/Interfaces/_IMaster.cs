﻿// Autor: Samuel Marti
// Start Date: 01.02.2017
// 
// Task of this File:
// Instantiate all the Game

#region Libraries
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;
#endregion

    public class _IMaster : MonoBehaviour
    {

    }

