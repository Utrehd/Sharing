﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class _IBuildings : _IMaster
{

    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    /// <summary>
    /// Panel in Unity
    /// </summary>
    public GameObject Panel;
    public Text textClose;
    public Text textLevel;
    public Text textUpgrade;
    public Button buttonUpgrade;
    public Text textUpgradeCost;
    public Text tagUpgradeCost;
    public Text tagLevel;
    public Text textTitle;
    public Text textDescription;
    public Text textMainButton;

    private _ViewBuildings vBuilding;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    protected void AssignReferences(_ViewBuildings arg)
    {
        vBuilding = arg;
    }

    public void ActivatePanelAction()
    {
        vBuilding.ActivatePanel();
    }

    public void DeactivatePanelAction()
    {
        vBuilding.DeactivatePanel();
    }
}

