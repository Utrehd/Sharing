﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * LastUpdate:17.04.2017
 * 
 * Task of this File:
 * The Recruting Center View
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
using System;
using TextKey = Global.Language.TextKey;
using UnityEditor;


public class ViewRecrutingCenter : _ViewBuildings
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    //private ViewSubscreen subscreen;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ViewRecrutingCenter (Application arg, _IBuildings arg2, _Buildings arg3, string title, string description) : base (arg,ref arg2,ref arg3,title,description)
    {
        // Assign Subscreen Data to Subscreen
        // subscreen = new ViewSubscreen(app.iRecrutingCenter.ISubscreenReferences);
        // Create Subscreen Data
        // subscreen.AssignData(app.mRecrutingCenter,
        // TextKey.RecCTitle,
        // TextKey.RecCDescription);


        DeactivatePanel();
        UpdateAll();
        EventManager.EventBattleEndedView += this.UpdateAll;
    }

    #region Buttons
    public void UpgradeRecutringCenter()
    {
        app.cRecrutingCenter.UpgradeRecrutingCenter();
        UpdateAll();
    }

    public void Recrut()
    {
        int recrutValue = ((int)app.iRecrutingCenter.sliderRecrut.value);
        app.cRecrutingCenter.Recrut(recrutValue);
        UpdateAll();
    }
    #endregion

    #region Slider
    public void SliderChange()
    {
        UpdateAll();
    }
    public void UpdateSlider()
    {
        app.iRecrutingCenter.sliderRecrut.maxValue = GetMaxPossibleRecrutsValue();
        Methods.AssignVariableToTag(((int)app.iRecrutingCenter.sliderRecrut.value), app.iRecrutingCenter.tagSlider);
    }

    /// <summary>
    /// Give the min value of avaible recruts, left places or afordable recruts back
    /// </summary>
    private int GetMaxPossibleRecrutsValue()
    {
        return Mathf.Min(app.mRecrutingCenter.AvaiableRecruts, app.cTents.LeftPlaces, app.mGold.Amount / app.mRecrutingCenter.CostPerRecrut); //Looks what is the smallest value
    }
    #endregion

    override public void UpdateAll()    //probalby we just need to update tags -> so 1 function UpdateTag and one UpdateText
    {
        //Parent
        UpdateAllGeneralTags();
        UpdateAllGeneralTexts();
        //Tags
        UpdateTagAvaiableRecruts();
        UpdateTagAvaiableRecrutsCost();
        UpdateTagNextLevelRecrutsPerBattle();
        UpdateTagRecrutsPerBattle();
        //Texts
        UpdateTextAvaiableRecruts();
        UpdateTextAvaiableRecrutsCosts();
        UpdateTextNextLevelRecrutsPerBattle();
        UpdateTextRecrutsPerBattle();
        
        //slider
        UpdateSlider();
        
        //buttons
        UpdateButtonHireRecruts();
        UpdateButtonInteractbility(app.iRecrutingCenter.buttonUpgrade, ((int)app.mRecrutingCenter.Costs), app.mGold.Amount);
        UpdateButtonInteractbility(app.iRecrutingCenter.buttonHireRecruts, 1, ((int)app.iRecrutingCenter.sliderRecrut.value));

        
    }

    #region PRIVATE All the update functions
    // UPDATE TAG METOHEDS
    private void UpdateTagAvaiableRecruts()
    {
        Methods.AssignVariableToTag(app.mRecrutingCenter.AvaiableRecruts, app.iRecrutingCenter.tagAvaiableRecruts);
    }
    private void UpdateTagAvaiableRecrutsCost()
    {
        Methods.AssignVariableToTag(app.mRecrutingCenter.AvaiableRecrutsCostTotal, app.iRecrutingCenter.tagAvaiableRecrutsCost);
    }
    private void UpdateTagRecrutsPerBattle()
    {
        Methods.AssignVariableToTag(app.mRecrutingCenter.RecrutsPerBattle, app.iRecrutingCenter.tagRecrustPerBattle);
    }
    private void UpdateTagNextLevelRecrutsPerBattle()
    {
        Methods.AssignVariableToTag(app.mRecrutingCenter.NextLevelRecrutsPerBattle, app.iRecrutingCenter.tagNextLevelRecrustPerBattle);
    }

    // UPDATE TEXT METOHDES
    private void UpdateTextAvaiableRecruts()
    {
        Methods.AssignTextToTag(TextKey.RecCAvaiableRecruts, app.iRecrutingCenter.textAvaiableRecruts);
    }

    private void UpdateTextNextLevelRecrutsPerBattle()
    {
        Methods.AssignTextToTag(TextKey.RecCNextLevelRec, app.iRecrutingCenter.textNextLevelRecrutsPerBattle);
    }
    private void UpdateTextRecrutsPerBattle()
    {
        Methods.AssignTextToTag(TextKey.RecCRecPerBattle, app.iRecrutingCenter.textRecurtsPerBattle);
    }
    private void UpdateTextAvaiableRecrutsCosts()
    {
        Methods.AssignTextToTag(TextKey.Cost, app.iRecrutingCenter.textAvaiableRecrutCost);
    }
    private void UpdateButtonHireRecruts()
    {
        Methods.AssignTextToTag(TextKey.RecCHire, app.iRecrutingCenter.textButtonHireRercuts);
    }
    #endregion // A

}
