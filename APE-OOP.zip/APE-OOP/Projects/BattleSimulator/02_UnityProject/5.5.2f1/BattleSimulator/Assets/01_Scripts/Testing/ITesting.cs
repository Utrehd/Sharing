﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[System.Serializable]
public class ITesting : _IMaster {

    public void BattleEndedAction()
    {
        EventManager.CallBattleEnd();
    }

    private VTesting vTesting;
    private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(VTesting arg)
    {
        vTesting = arg;
        viewAssigned = true;
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void BatRand()
    {
        if (viewAssigned)
        {
            vTesting.BattleRandom();
        }
    }
}
