﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Global;
using UnityEngine.UI;


public class _ViewMaster
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    protected Application app;
    private Animator animator;

    public _ViewMaster(ref Application arg)
    {
        app = arg;
    }

    /// <summary>
    /// This function will update the interactability of buttons if refValue bigger than max than not interactable
    /// </summary>
    /// <param name="button"></param>
    /// <param name="refValue"></param>
    /// <param name="maxValue"></param>
    protected void UpdateButtonInteractbility(Button button, int refValue, int maxValue)
    {
        if (refValue > maxValue)
        {
            button.interactable = false;
        }
        else
        {
            button.interactable = true;
        }
    }

    protected void CallAnimationSmallerBigger(Text text, string changeTrend)
    {
        // Get Animator
        animator = text.GetComponent<Animator>();

        // Choose Animation
        if (changeTrend != "SAME")
        {
            if (changeTrend == "SMALLER")
            {
                animator.SetTrigger("TriggerSMALLER");
            }
            else
            {
                animator.SetTrigger("TriggerBIGGER");
            }
        }
    }
}

