﻿// Autor: Samuel Marti
// Start Date: 01.02.2017
// 
// Task of this File:
// Will use a Subscreen Data in order to assign basic subscreen stuff.

#region Libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Global;
using UnityEngine;
using UnityEngine.UI;
using TextKey = Global.Language.TextKey;
#endregion

public class ViewSubscreen : _ViewMaster
{
    //********************************************************************************************
    // Declarations, declare Subscreen data and assign subscreen.
    //********************************************************************************************
    #region
    ISubscreen ISubscreen;

    /// <summary>
    /// Assign SubscreenData
    /// </summary>
    /// <param name="_References"></param>
    public ViewSubscreen(Application arg, ISubscreen _References) : base (ref arg)
    {
        ISubscreen = _References;
    }
    #endregion

    //********************************************************************************************
    // Functions
    //********************************************************************************************
    #region Public Functions
    public void UpdateAll()
    {
        UpdateTagCosts();
        UpdateTagLevel();
        UpdateTextLevel();
        UpdateTextBuy();
        UpdateTextClose();
        UpdateTextDescription();
        UpdateTextTitle();
        UpadteTextCost(); 
    }
    /// <summary>
    /// Assign Arguments
    /// </summary>
    /// <param name="_building"></param>
    /// <param name="text _keyTitle"></param>
    /// <param name="text _keyDescription"></param>
    public void AssignData(
        _Buildings _building,
        string _keyTitle,
        string _keyDescription)
    {
        ISubscreen.keyDescription = _keyDescription;
        ISubscreen.keyTitle = _keyTitle;
        ISubscreen.building = _building;
    }

    #endregion

    #region Private Functions
    private void UpdateTagCosts()
    {
        Methods.AssignVariableToTag(Convert.ToInt32(app.mTents.Costs), ISubscreen.tagUpgradeCost);
    }
    // TODO: SOMETHING STRANGE IS HERER, WHERE DO I GET THE DATA FROM FOR THE SUBSCREENS... DRAW A DIAGRAM??
    private void UpdateTagLevel()
    {
        Methods.AssignVariableToTag(ISubscreen.building.Level, ISubscreen.tagLevel);
    }

    private void UpdateTextTitle()
    {
        Methods.AssignTextToTag(ISubscreen.keyTitle, ISubscreen.textTitle);
    }
    private void UpdateTextDescription()
    {
        Methods.AssignTextToTag(ISubscreen.keyDescription, ISubscreen.textDescription);
    }

    private void UpdateTextClose()
    {
        Methods.AssignTextToTag(Language.TextKey.Close, ISubscreen.textClose);
    }

    private void UpdateTextBuy()
    {
        Methods.AssignTextToTag(Language.TextKey.Buy, ISubscreen.textUpgrade);
    }

    private void UpdateTextLevel()
    {
        Methods.AssignTextToTag(Language.TextKey.Level, ISubscreen.textLevel);
    }

    private void UpadteTextCost()
    {
        Methods.AssignTextToTag(TextKey.Cost, ISubscreen.textUpgradeCost);
    }
    #endregion
}
