﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * The Tent View
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;
using System;
using TextKey = Global.Language.TextKey;

public class ViewTents : _ViewBuildings {
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    //private ViewSubscreen subscreen;


    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    public ViewTents(Application arg, _IBuildings arg2, _Buildings arg3, string title, string description) : base(arg, ref arg2, ref arg3, title, description)
    {
        // Assign Subscreen

        //subscreen = new ViewSubscreen(app.iTent.ISubscreenReferences);
        //subscreen.AssignData
        //(
         //   app.mTents,
          //  TextKey.TentTitle,
           // TextKey.TentDescription
        //);
        DeactivatePanel();
        UpdateAll();
        
    }

    #region Buttons
    public void UpgradeTent()
    {
        app.cTents.UpgradeTentAction();
        UpdateAll();
    }
    #endregion

    #region Update Functions
    override public void UpdateAll()
    {
        //Parent
        UpdateAllGeneralTags();
        UpdateAllGeneralTexts();

        //This
        UpdateTagUsedPlaces();
        UpdateTagPlaces();
        UpdateTextPlaces();

        // Button
        UpdateButtonInteractbility(app.iTent.buttonUpgrade, ((int)app.mTents.Costs), app.mGold.Amount);
    }

    // UPDATE TAG METOHEDS
    private void UpdateTagPlaces()
    {
        Methods.AssignVariableToTag(app.mTents.Places, app.iTent.tagPlaces);
    }
    
    private void UpdateTagUsedPlaces()
    {
        Methods.AssignVariableToTag(app.mTroops.Amount, app.iTent.tagUsedPlaces);
    }

    // UPDATE TEXT METOHDES
    private void UpdateTextPlaces()
    {
        Methods.AssignTextToTag(Language.TextKey.TentPlaces, app.iTent.textPlaces);
    }
    #endregion 
}
