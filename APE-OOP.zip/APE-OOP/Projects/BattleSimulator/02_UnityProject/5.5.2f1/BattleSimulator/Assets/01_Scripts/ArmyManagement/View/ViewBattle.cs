﻿/**
 * Autor: David Geisser
 * Start Date: 05.05.2017
 * Last Update: 05.05.2017
 * 
 * Task of this File:
 * View of Battle
 */

using UnityEngine;
using UnityEditor;
using System.Collections;
using UnityEngine.UI;
using Global;
using TextKey = Global.Language.TextKey;

public class ViewBattle : _ViewMaster
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    //--------------------------
    // Constructor
    //--------------------------
    public ViewBattle(Application arg) : base(ref arg)
    {
        DeactivatePanel();
        //----------------------
        // Add Events
        //----------------------
        EventManager.EventBattleEndedView += this.DeactivatePanel;
    }

    //--------------------------
    // Public
    //--------------------------

    // Click Function
    public void ActivatePanel()
    {
        app.iBattle.panel.SetActive(true);
    }

    public void DeactivatePanel()
    {
        app.iBattle.panel.SetActive(false);
    }

    //--------------------------
    // Private
    //--------------------------

}
