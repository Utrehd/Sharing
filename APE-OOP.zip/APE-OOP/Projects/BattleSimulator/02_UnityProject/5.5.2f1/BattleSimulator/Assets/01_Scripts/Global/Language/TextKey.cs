﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Global
{
    public partial class Language
    {
        /// <summary>
        /// The Language Texts Keys, Add the text keys in english
        /// </summary>
        public static class TextKey
        {
            public const string        // Init the Text Keys
                Title = "Title",
                Experience = "Exp",
                Cheat = "Cheat",
                GoldSymbol = "GoldSymbol",
                Settings = "Settings",
                Close = "Close",
                Upgrade = "Upgrade",
                Level = "Level",
                Buy = "buy",
                Cost = "Costs",
                Start = "Start",

                // Recruting Center Texts
                RecCAvaiableRecruts = "RecCAvRec",
                RecCDescription = "RecCDescription",
                RecCTitle = "ReCTitle",
                RecCRecPerBattle = "RecCRecPerBattle",
                RecCNextLevelRec = "RecCNextLevelRec",
                RecCHire = "RecCHire",

                // PopupMessages
                NoGold = "NoGold",
                NoRecruts = "NoRecruts",
                NoPlaces = "NoPlaces",

                // Tents Texts
                TentPlaces = "Places",
                TentTitle = "tentTitle",
                TentDescription = "tentDescription",

                //TrainingGround Texts
                TrainingGroundTitle = "TrainingGroundTitle",
                TrainingGroundDescription = "TrainingGroundDescription",
                TrainingGroundExpPerTrain = "TrainingGroundExpPerTrain",
                TrainingGroundNextLevelExp = "TrainingGroundNextLevelExp",
                TrainingGroundTrain = "TrainingGroundTrain",

                // Blacksmith Texts
                BlacksmithSell = "BlacksmithSell",
                BlacksmithTitle = "BlacksmithTitle",
                BlacksmithDescription = "BlacksmithDescription",

                // Battle Subscreen Texts
                BattleTitle = "BattleTitle",
                BattleDescription = "BattleDescription",

                //Weapon Texts
                Weapon1001 = "Weapon1001",
                Weapon2001 = "Weapon2001",
                Weapon3001 = "Weapon3001",
                Weapon4001 = "Weapon4001",
                Weapon5001 = "Weapon5001";

        }
    }
}
