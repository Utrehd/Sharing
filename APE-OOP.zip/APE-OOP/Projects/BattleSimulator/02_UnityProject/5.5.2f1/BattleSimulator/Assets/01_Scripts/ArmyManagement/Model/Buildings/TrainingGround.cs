﻿// Autor: David Geisser 
// Start Date: 15.04.2017
// Last Update: 15.04.2017
// 
// Task of this File:
// The Training Ground Model

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public class TrainingGround : _Buildings
{

    /// <summary>
    /// TG Constructor, is called automatic when new TG object generated.
    /// </summary>
    public TrainingGround() //Default Constructor TG
    {
        ExpPerTrainBase = 2;   //Set TG Varaibles to Start Value -> Later: Load from SaveData
        Costs = 5;
        UpgradeModificator = 200;
        Level = 1;
        CostPerTrainBase = 1;
        MaxLevelBuilding = 20;
    }

    /// <summary>
    /// The Experience you receive Per Train
    /// </summary>
    public int ExpPerTrain
    {
        get
        {
            return ExpPerTrainBase * Level;
        }
    }

    /// <summary>
    /// Cost per Train section basis
    /// </summary>
    public int CostPerTrainBase { get; set; }

    /// <summary>
    /// The total cost for training in on BuildingLevel 
    /// </summary>
    public int TrainCostTotal
    {
        get
        {
            return CostPerTrainBase * (MaxLevelBuilding - Level - 1); //Training is cheaper with higher level
        }
    }

    /// <summary>
    /// The Amount of Exp per Training in the next level of the building
    /// </summary>
    public int NextLevelExpPerTrain
    {
        get
        {
            return ExpPerTrainBase * (Level + 1);
        }
    }

    /// <summary>
    /// The ExpPerTrain Base number
    /// </summary>
    public int ExpPerTrainBase { get; set; }
}

