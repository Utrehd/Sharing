﻿/**
 * Autor: David Geisser
 * Start Date: 14.04.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * Interface of Training Grounds
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;

[System.Serializable]
public class ITrainingGround : _IBuildings
{
    
    //********************************************************************************************
    // Declarations
    //********************************************************************************************

    public Text textTrainCost;
    public Text tagTrainCost;

    public Text textExpPerTrain;
    public Text tagExpPerTrain;
    public Text textNextLevelExp;
    public Text tagNextLevelExp;

    public Text buttonTrain;

    //public ISubscreen ISubscreenReferences = new ISubscreen();

    private ViewTrainingGround vTrainingGround;
    //private bool viewAssigned;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewTrainingGround arg)
    {
        vTrainingGround = arg;
        //viewAssigned = true;
        AssignReferences(arg);
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void UpgradeTrainingGroundAction()
    {
        vTrainingGround.UpgradeTrainingGround();
    }
    public void TrainAction()
    {
        vTrainingGround.Train();
    }
}