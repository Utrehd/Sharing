﻿/**
 * Autor: David Geisser
 * Start Date: 05.05.2017
 * Last Update: 05.05.2017
 * 
 * Task of this File:
 * Interface of Battle
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class IBattle : MonoBehaviour
{
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    public GameObject panel;
    public GameObject soldier;

    private ViewBattle vBattle;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************


    //--------------------------
    // User Input
    //--------------------------
    public void Update()
    {
        if (Input.GetMouseButtonDown(0) && panel.activeSelf) //is called when mouse is clicked and battle scene is active
        {
            Debug.Log("Pressed left click.");
            Debug.Log("TODO: add function place soldier here");
            Quaternion spawnRotation = new Quaternion();
            Instantiate(soldier, Input.mousePosition, spawnRotation);
            Debug.Log("TODO: detect swipe instead of click");
        }
        //Additional no use yet
        if (Input.GetMouseButtonDown(1))
            Debug.Log("Pressed right click.");

        if (Input.GetMouseButtonDown(2))
            Debug.Log("Pressed middle click.");

    }

    //--------------------------
    // Assignment
    //--------------------------
    public void AssignView(ref ViewBattle arg)
    {
        vBattle = arg;
    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void ActivateAction()
    {
        vBattle.ActivatePanel();
    }

    public void DeactivateAction()
    {
        vBattle.DeactivatePanel();
    }
}