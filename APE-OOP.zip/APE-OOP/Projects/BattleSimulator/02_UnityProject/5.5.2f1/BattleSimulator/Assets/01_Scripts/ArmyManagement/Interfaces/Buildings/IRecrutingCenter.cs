﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * LastUpdate:17.04.2017
 * 
 * Task of this File:
 * The Recruting Center Interface
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;

[System.Serializable]
public class IRecrutingCenter : _IBuildings {

    //********************************************************************************************
    // Declarations
    //********************************************************************************************

    public Text textAvaiableRecruts;
    public Text tagAvaiableRecruts;
    public Text textAvaiableRecrutCost;
    public Text tagAvaiableRecrutsCost;

    public Text textRecurtsPerBattle;
    public Text tagRecrustPerBattle;
    public Text textNextLevelRecrutsPerBattle;
    public Text tagNextLevelRecrustPerBattle;

    public Text tagSlider;

    public Button buttonHireRecruts;
    public Text textButtonHireRercuts;

    public Slider sliderRecrut;

    //public ISubscreen ISubscreenReferences = new ISubscreen();

    private ViewRecrutingCenter vRecrutingCenter;
    //private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    public void AssignView(ref ViewRecrutingCenter arg)
    {
        vRecrutingCenter = arg;
        //viewAssigned = true;
        AssignReferences(arg);

    }

    //--------------------------
    // Button Assignment
    //--------------------------
    public void UpgradeRecrutingCenterAction()
    {
        vRecrutingCenter.UpgradeRecutringCenter();
    }
    public void RecrutAction()
    {
        vRecrutingCenter.Recrut();
    }
    //--------------------------
    // Slider Assignment
    //--------------------------
    public void SliderAction()
    {
        vRecrutingCenter.SliderChange();
    }
}
