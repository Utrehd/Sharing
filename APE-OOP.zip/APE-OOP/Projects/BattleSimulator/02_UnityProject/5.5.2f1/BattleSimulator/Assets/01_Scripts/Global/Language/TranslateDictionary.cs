﻿/**
 * Autor: Samuel Marti
 * Start Date: 27.12.2016
 * 
 * Task of this File:
 * Manage the use of multible language
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;
using System;

/// <summary>
/// This class is just used for creating a 2D dirictory for the language class
/// See here the link http://stackoverflow.com/questions/17121045/multidimensional-dictionary-with-add-new-value-if-key-not-in-dictionary
/// </summary>
/// <typeparam name="TKey"></typeparam>
/// <typeparam name="TValue"></typeparam>
public class TranslateDictionary<TKey, TValue>
{
    public bool Initialized { get; set; }
    private Dictionary<TKey, TValue> Dictionary = new Dictionary<TKey, TValue>();
    public TValue this[TKey lang]
    {
        get
        {
            if (!Initialized)
            {
                if (!Dictionary.ContainsKey(lang))
                {
                    Dictionary.Add(lang, Activator.CreateInstance<TValue>());
                }
            }
            return Dictionary[lang];
        }
        set
        {
            Dictionary[lang] = value;
        }
    }
}
