﻿/**
 * Autor: David Geisser
 * Start Date: 29.04.2017
 * Last Update: 29.04.2017
 * 
 * Task of this File:
 * This Controller controls the blacksmith rules
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;

public class ControllerBlacksmith : ControllerCamp
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerBlacksmith(Application arg) : base(arg) { }
    //--------------------------
    // Public
    //--------------------------
    #region Public
    public void UpgradeBlacksmith()
    {
        TryToUpgrade(app.mBlacksmith);
    }

    public void BuyWeapon(int price, int ID)
    {
        if (EnoughGoldForCost(price))
        {
            Pay(price);
            AddWeapon(ID);
        }
    }

    //later sellWeapon

    #endregion
    //--------------------------
    // Private
    //--------------------------
    #region Private
    private void AddWeapon(int ID)  // should add weapon to inventory
    {
        Debug.Log("Add Weapon"+ID.ToString());  //not finished yet
    }
    #endregion
}