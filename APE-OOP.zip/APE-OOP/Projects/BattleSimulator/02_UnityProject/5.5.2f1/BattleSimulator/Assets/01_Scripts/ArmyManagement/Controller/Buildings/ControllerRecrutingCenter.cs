﻿/**
 * Autor: Samuel Marti & David Geisser
 * Start Date: 11.02.2017
 * Last Update: 17.04.2017
 * 
 * Task of this File:
 * This Controller controls the recruting rules
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Global;

public class ControllerRecrutingCenter : ControllerCamp
{

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public ControllerRecrutingCenter(Application arg) : base(arg) {}
    //--------------------------
    // Public
    //--------------------------
    #region Public
    public void UpgradeRecrutingCenter()
    {
        TryToUpgrade(app.mRecrutingCenter);
    }


    public void Recrut(int recrutNr) //functions with var is to avoid errors
    {
        if (EnoughRecruts(recrutNr) & EnoughPlaces(recrutNr))
        {
            TryToHireRecruts(recrutNr);
        }
    }

    public void AddRecruts() //Changed name
    {
        app.mRecrutingCenter.AvaiableRecruts += app.mRecrutingCenter.RecrutsPerBattle; //Add new recruts to old amount ¦ X += Y equal X = X + Y 
    }

    /// <summary>
    /// Checks if there are more avaiable recruts or places
    /// </summary>
    public void UpdateRecrutNr(float slider)
    {
        app.mRecrutingCenter.UserNrOfRecruts = CalcRecrutNr(slider, RecrutMin());     //calculate the user NR with the smallest nr and the position of the slider
    }
    #endregion
    //--------------------------
    // Private
    //--------------------------
    #region Private
    private bool EnoughPlaces(int needPlaces)
    {
        if (needPlaces > app.cTents.LeftPlaces)
        {
            EventManager.CallPopup(Language.TextKey.NoPlaces);
            return false;
        }
        else
        {
            return true;
        }
    }

    private bool EnoughRecruts(int needRecruts)
    {
        if (app.mRecrutingCenter.AvaiableRecruts < needRecruts)
        {
            app.vPopup.Call(Language.TextKey.NoRecruts);
            return false;
        }
        else
        {
            return true;
        }
    }

    private void TryToHireRecruts(int recrutsNr)
    {
        if (EnoughGoldForCost(app.mRecrutingCenter.UserCostRecrut))
        {
            Pay(app.mRecrutingCenter.CostPerRecrut * recrutsNr);
            AddTroops(recrutsNr);
            RemoveRecruts(recrutsNr);
        }
    }

    private void AddTroops(int addRecruts)
    {
        app.mTroops.Amount += addRecruts;
    }

    private void RemoveRecruts(int removeRecruts)
    {
        app.mRecrutingCenter.AvaiableRecruts -= removeRecruts;
    }

    /// <summary>
    /// Calculate the Nr of Recruts with variable mod uses slider value (in %)
    /// </summary>
    private int CalcRecrutNr(float sliderValue, int maxValue)
    {
        return (maxValue * ((int) sliderValue)) / 100; //Slider value can be from 0 to 100 (100 would be all possible recruts) 
    }

    /// <summary>
    /// Give the min value of avaible recruts, left places or afordable recruts back
    /// </summary>
    private int RecrutMin()
    {                   
        return Mathf.Min(app.mRecrutingCenter.AvaiableRecruts, app.cTents.LeftPlaces, app.mGold.Amount / app.mRecrutingCenter.CostPerRecrut); //Looks what is the smallest value
    }
    #endregion
}