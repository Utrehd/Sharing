﻿/**
 * Autor: David Geisser
 * Start Date: 16.04.2017
 * 
 * Task of this File:
 * Testing View
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Global;

public class VTesting : _ViewMaster
{
    //--------------------------
    // Constructor
    //--------------------------
    public VTesting(Application arg) : base(ref arg) { }

    public void BattleRandom() //Testing Method
    {
        app.mTroops.Amount -= (int) (Random.value * 10);
        app.mGold.Amount += (int)(Random.value * 100);
        app.mExperience.AmountExp += (int)(Random.value * 10);
        EventManager.CallBattleEnd();
    }
}
