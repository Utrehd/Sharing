﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * Last Update: 14.04.2017
 * 
 * Task of this File:
 * Commenting Example
 */

#region Libraries

#endregion

class Example
{
    #region Declarations
    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    #region Public
    //--------------------------
    // Public
    //--------------------------
    #endregion
    #region Private
    //--------------------------
    // Private
    //--------------------------
    #endregion
    #region Properties
    //--------------------------
    // Properties
    //--------------------------
    #endregion
    #endregion

    #region Metohdes
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    #region Constructor
    //--------------------------
    // Constructor
    //--------------------------
    #endregion

    #region Public
    //--------------------------
    // Public
    //--------------------------
    #endregion
    #region Private
    //--------------------------
    // Private
    //--------------------------
    #endregion

    #endregion
}