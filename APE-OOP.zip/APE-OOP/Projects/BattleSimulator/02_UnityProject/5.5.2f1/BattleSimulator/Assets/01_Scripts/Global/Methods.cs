﻿/**
 * Autor: David Geisser
 * Start Date: 27.12.2016
 * Last Update: 17.04.2017
 * 
 * Task of this File:
 * All our Global Methods are in this file
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Global;

namespace Global
{
    public static class Methods
    {
        /// <summary>
        /// Assign Int to TagText
        /// </summary>
        /// <param name="var"></param>
        /// <param name="tag"></param>
        public static void AssignVariableToTag(int var, Text tag)
        {
            tag.text = var.ToString();
        }

        /// <summary>
        /// Assign float to TagText
        /// </summary>
        /// <param name="var"></param>
        /// <param name="tag"></param>
        public static void AssignVariableToTag(float var, Text tag)     //Same as int -> compiler find the right function
        {
            tag.text = var.ToString();
        }

        /// <summary>
        /// Assign a Dictionary Key to the TagText
        /// </summary>
        /// <param name="key"></param>
        /// <param name="tag"></param>
        public static void AssignTextToTag(string key, Text tag)
        {
            tag.text = Language.Instance.Dictionary[Language.Instance.Current][key];
        }

    }

}// End namespace Global
