﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * The Buliding Model
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _Buildings : _ModelMaster
{
    /// <summary>
    /// The Level of the Building
    /// </summary>
    public int Level { get; set; }

    /// <summary>
    /// The Costs of the Building
    /// </summary>
    public double Costs { get; set; }       //why double??
    
    /// <summary>
    /// The Factor is in Percanteg. E.G 200 will double the value
    /// </summary>
    public int UpgradeModificator { get; set; }

    /// <summary>
    /// The highest Level of the Building
    /// </summary>
    public int MaxLevelBuilding { get; set; }
}
