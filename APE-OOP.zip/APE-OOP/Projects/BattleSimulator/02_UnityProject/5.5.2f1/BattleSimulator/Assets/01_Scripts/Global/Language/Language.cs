﻿/**
 * Autor: Samuel Marti
 * Start Date: 27.12.2016
 * 
 * Task of this File:
 * Manage the use of multible language
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace Global
{
    /// <summary>
    /// This Class takes care about the languages
    /// </summary>
    public partial class Language
    {
       
        public string Current { get; set; }
        // SingeltonPattern
        private static Language instance;
        public static Language Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Language();
                }
                return instance;
            }
        }
        
        // Initiated a langauge direcotry it is 2D
        public TranslateDictionary<string, TranslateDictionary<string, string>> Dictionary { get; set; }

        /// <summary>
        /// Will set the Language To German
        /// </summary>
        public void SetToGerman()
        {
            Language.Instance.Current = LanguageKey.German;
        }

        /// <summary>
        /// Will set the Language To English
        /// </summary>
        public void SetToEnglish()
        {
            Language.Instance.Current = LanguageKey.English;
        }
    }
}



