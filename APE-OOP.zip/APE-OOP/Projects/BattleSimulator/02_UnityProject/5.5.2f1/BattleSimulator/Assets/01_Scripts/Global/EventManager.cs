﻿// Autor: Samuel Marti
// Start Date: 01.02.2017
// Last Update: 14.04.2017 
//
// Task of this File:
// Manage Events which controlls a overlay screen

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Global;


class EventManager
{
    public delegate void DelegateEmpty();
    public static event DelegateEmpty EventBattleEndedController;   //should be called when the battle ends
    public static event DelegateEmpty EventBattleEndedView;         //should be called when the battle ends
    public static event DelegateEmpty EventBattleStart;             //should be called at start of battle


    // Metohd is called when battle ends
    public static void CallBattleEnd()
    {
        // Check if event are already triggered
        if (EventBattleEndedController != null & EventBattleEndedView != null)
        {
            // Trigger first the calculations on controller side
            EventBattleEndedController();
            // Trigger the View, which will update the new calculations
            EventBattleEndedView();
        }
    }

    //event is called when battle screne gets opened
    public static void CallBattleStart()
    {
        // Check if event are already triggered
        if (EventBattleStart != null)
        {
            // Start Battle Controller
            EventBattleStart();
            Debug.Log("EventStartBattle");
        }
    }

    public delegate void Popup(string _key);
    public static event Popup ErrorPopup;

    public static void CallPopup(string _key)
    {
        ErrorPopup(_key);
    }

    public delegate void DeactivatePanels();
    public static event DeactivatePanels DeactivateAllPanels;
    
    public static void CallDeactivateAllPanels()
    {
        DeactivateAllPanels();
    }
}

