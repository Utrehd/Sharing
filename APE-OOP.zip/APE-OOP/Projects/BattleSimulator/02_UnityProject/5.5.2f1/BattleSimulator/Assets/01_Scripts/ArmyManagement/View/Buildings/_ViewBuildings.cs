﻿/**
 * Autor: Samuel Marti
 * Start Date: 11.02.2017
 * 
 * Task of this File:
 * The main Parent View
 */

#region Libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Global;
using UnityEngine;
using UnityEngine.UI;
using TextKey = Global.Language.TextKey;
#endregion

public class _ViewBuildings : _ViewMaster
{

    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    private _IBuildings iBuildings;
    private _Buildings mBuildings;
    private string keyTitle;
    private string keyDescription;

    //********************************************************************************************
    // Metohdes
    //********************************************************************************************
    //--------------------------
    // Constructor
    //--------------------------
    public _ViewBuildings(Application arg, ref _IBuildings arg2, ref _Buildings arg3, string title, string description ) : base(ref arg) //pass objects by reference not by value, when possible
    {
        iBuildings = arg2;
        mBuildings = arg3;
        keyTitle = title;
        keyDescription = description;

        // Add function to event manager
        EventManager.DeactivateAllPanels += this.DeactivatePanel;
    }

    // Click Function
    public void ActivatePanel()
    {
        // Sent event for closing all current panel out
        EventManager.CallDeactivateAllPanels();
        iBuildings.Panel.SetActive(true);
        UpdateAll();
    }

    public void DeactivatePanel()
    {
        iBuildings.Panel.SetActive(false);
        UpdateAll();
    }

    //--------------------------
    // Virtual
    //--------------------------
    /// <summary>
    /// Update All, Texts and tags of the view
    /// </summary>
    virtual public void UpdateAll()
    {
    }

    protected void UpdateAllGeneralTags()
    {
        // Costs
        Methods.AssignVariableToTag(Convert.ToInt32(mBuildings.Costs), iBuildings.tagUpgradeCost);
        // Level
        Methods.AssignVariableToTag(mBuildings.Level, iBuildings.tagLevel);
    }

    protected void UpdateAllGeneralTexts()
    {
        // Description
        Methods.AssignTextToTag(keyTitle, iBuildings.textTitle);
        // Title
        Methods.AssignTextToTag(keyDescription, iBuildings.textDescription);
        Methods.AssignTextToTag(keyTitle, iBuildings.textMainButton);
        // Close
        Methods.AssignTextToTag(Language.TextKey.Close, iBuildings.textClose);
        // Buy
        Methods.AssignTextToTag(Language.TextKey.Upgrade, iBuildings.textUpgrade);
        // Update
        Methods.AssignTextToTag(Language.TextKey.Level, iBuildings.textLevel);
        // Costs
        Methods.AssignTextToTag(TextKey.Cost, iBuildings.textUpgradeCost);

    }
}
