﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class IInfoBar : _IMaster {

    //********************************************************************************************
    // Declarations
    //********************************************************************************************
    public Text MoneyText;
    public Text ArmyPlaces;
    public Text ArmyText;       //Variables for Text Fields of the InfoBar
    public Text ExpText;

    // Create View
    private ViewInfoBar vInfoBar;
    private bool viewAssigned;
    //********************************************************************************************
    // Metohdes
    //********************************************************************************************

    public void AssignView(ref ViewInfoBar arg)
    {
        vInfoBar = arg;
        viewAssigned = true;
    }
}
