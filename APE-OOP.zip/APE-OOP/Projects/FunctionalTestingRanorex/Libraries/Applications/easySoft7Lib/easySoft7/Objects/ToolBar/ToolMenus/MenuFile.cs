﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 7/10/2017
// Time: 1:05 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
using StandardControls;
#endregion

namespace easySoft7Lib.easySoft7.ToolMenus
{
	/// <summary>
	/// Description of File.
	/// </summary>
	public class MenuFile : ToolMenu
	{
		/// <summary>
		/// Object for opening the toolmenu
		/// </summary>
		private static Ranorex.MenuItem menuButton = Repo.easySoft7.Toolbar.FileMenu.File;
		
		/// <summary>
		/// The New Button
		/// </summary>
		public Ranorex.MenuItem optionNew = Repo.easySoft7.Toolbar.FileMenu.New;
		
		/// <summary>
		/// Project Number
		/// </summary>
		public Ranorex.MenuItem optionProjectInfo = Repo.easySoft7.Toolbar.FileMenu.ProjectInfo;
		
		/// <summary>
		///	Close the project
		/// </summary>
		public Ranorex.MenuItem optionClose = Repo.easySoft7.Toolbar.FileMenu.Close;
		
		/// <summary>
		/// Open a Project
		/// </summary>
		public Ranorex.MenuItem optionOpen = Repo.easySoft7.Toolbar.FileMenu.Open;
		
		/// <summary>
		/// Save
		/// </summary>
		public Ranorex.MenuItem optionSave = Repo.easySoft7.Toolbar.FileMenu.Save;
		
		/// <summary>
		/// Save As
		/// </summary>
		public Ranorex.MenuItem optionSaveAs = Repo.easySoft7.Toolbar.FileMenu.SaveAs;
		
		/// <summary>
		/// Page Preview
		/// </summary>
		public Ranorex.MenuItem optionPagePreview = Repo.easySoft7.Toolbar.FileMenu.PagePreview;
		
		/// <summary>
		/// Form Setup
		/// </summary>
		public Ranorex.MenuItem optionFormSetup = Repo.easySoft7.Toolbar.FileMenu.PrinterSetup;
		
		/// <summary>
		/// Print 
		/// </summary>
		public Ranorex.MenuItem optionPrint = Repo.easySoft7.Toolbar.FileMenu.Print;
		
		/// <summary>
		/// Printer Setup
		/// </summary>
		public Ranorex.MenuItem optionPrinterSetup = Repo.easySoft7.Toolbar.FileMenu.PrinterSetup;
		
		/// <summary>
		/// Last File
		/// </summary>
		public Ranorex.MenuItem optionLastFile = Repo.easySoft7.Toolbar.FileMenu.LastFile;
		
		/// <summary>
		/// Exit the Application
		/// </summary>
		public Ranorex.MenuItem optionExit = Repo.easySoft7.Toolbar.FileMenu.Exit;
		
		/// <summary>
		/// Consturctor Pass menuButton to parent
		/// </summary>
		public MenuFile():base(menuButton)
		{}
	}
}
