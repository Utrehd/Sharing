﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 7/10/2017
// Time: 12:57 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
using easySoft7Lib.easySoft7.ToolMenus;
#endregion

namespace easySoft7Lib.easySoft7
{
	/// <summary>
	/// Description of Toolbar.
	/// </summary>
	public class Toolbar
	{
		public MenuFile file = new MenuFile();
		
		public Toolbar()
		{
		}
	}
}
