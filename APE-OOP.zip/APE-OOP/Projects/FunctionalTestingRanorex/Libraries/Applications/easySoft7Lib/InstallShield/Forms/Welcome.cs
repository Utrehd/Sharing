﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of W02_Welcome.
	/// </summary>
	public class Welcome : InstallShieldAdvancedControl
	{
		// Assing Object for Parent
		private static RepoItemInfo TextTitle = Repo.Wizard.WelcomeToInstallShield.TitleTextInfo;
		
		/// <summary>
		/// The PopUp which show if you want to exsit the Menu
		/// </summary>		
		public PopUp popup;
		
		public Welcome(AppSkeleton argApplication) :base (argApplication, TextTitle)
		{
			// Assign My State
			MyState.Entry.Default = EStates.LanguageSelection;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.Agreement;
			MyState.Work.Default = EStates.Welcome;
			MyState.Proceed.Add(EStates.Maintenance);
			
			// For the PopUp
			popup = new PopUp(argApplication, MyState.Work.Default);
			
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
		}
		
		/// <summary>
		/// This Metohde will Open this window from the entry state side.
		/// </summary>
		public void Open()
		{
			MyState.Entry.ValidatePoint();	
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			application.State.Current = MyState.Work.Default;
		}
		
		public void OpenMaintainance()
		{
			Methods.StartExe(application.SpecificNewestSetupDir);	
			application.State.Current = EStates.Welcome;				
		}
		
		public void ProceedToMaintenance()
		{
			Methods.Click(buttonProceed);
			application.State.Current = EStates.Maintenance;
		}
	}
}
