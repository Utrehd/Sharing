﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of CustomSetup.
	/// </summary>
	public class CustomSetup : InstallShieldAdvancedControl
	{
		// Assign For Parent
		private static RepoItemInfo textTitle = Repo.Wizard.CustomSetup.TextTitleInfo;

		// Assign For This
		private static RepoItemInfo buttonChangePath = Repo.Wizard.CustomSetup.ButtonChangePathInfo;
		
		/// <summary>
		/// The PopUp which show if you want to exsit the Menu
		/// </summary>		
		public PopUp popup;
		
		/// <summary>
		/// The Change Dir Window if clicked on Change Dir
		/// </summary>
		public ChangeDir changeDir;
		
		public CustomSetup(AppSkeleton argApplication) : base (argApplication, textTitle)
		{
			// Assign the My States
			MyState.Entry.Default = EStates.SetupType;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.ReadyToInstall;
			MyState.Work.Default = EStates.CustomSetup;
			
			popup = new PopUp(argApplication, MyState.Work.Default);
			
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
			
			// Add Validations
			validation.ExistItems.Add(buttonChangePath);
			validation.NoneExistItems.Add(buttonChangePath);
		}
		
		/// <summary>
		/// This Metohde will Open this window from the entry state side.
		/// </summary>
		public void Open()
		{
			MyState.Entry.ValidatePoint();
			Methods.Click(Repo.Wizard.SetupType.RadioButtonCustomInfo);
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			application.State.Current = MyState.Work.Default;
		}
		/// <summary>
		/// This Button Will Open the Change Dir Window
		/// </summary>
		public void ClickChangeDir()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Check the Agreement Button
			Methods.Click(buttonChangePath);
			
			changeDir = new ChangeDir(application, MyState.Work.Default);
			
			application.State.Current = EStates.ChangeDir;
		}
	}
}
