﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/8/2017
// Time: 1:59 PM
// Description:
// This class is implementing the generic basic control 
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Forms;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShieldControlAdvanced.
	/// </summary>
	abstract public class InstallShieldAdvancedControl : AdvancedFormSkeleton
	{
		#region #### DECLARATIONS ####
		// Assign the Installshield control for the generic stuff
		private static RepoItemInfo ButtonBack = Repo.Wizard.General.ButtonBackInfo;
		private static RepoItemInfo ButtonCancelX = Repo.Wizard.General.ButtonCancelXInfo;
		private static RepoItemInfo ButtonProceed = Repo.Wizard.General.ButtonProceedInfo;
		private static RepoItemInfo ButtonCancel = Repo.Wizard.General.ButtonCancelInfo;
		private static RepoItemInfo Form = Repo.Wizard.SelfInfo;
		#endregion
		
		#region #### CONSTRUCTOR ####
		public InstallShieldAdvancedControl
			(
				AppSkeleton argApplication,
				RepoItemInfo argTextSpecific
			) 
			:base
			(
				argApplication,
				Form,
				argTextSpecific,
				ButtonProceed,
				ButtonCancel,
				ButtonCancelX,
				ButtonBack
			)
		{
		}
		#endregion	
	}
}
