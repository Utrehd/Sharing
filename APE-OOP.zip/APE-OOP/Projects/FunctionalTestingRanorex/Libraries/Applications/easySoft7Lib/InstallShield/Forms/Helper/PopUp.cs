﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/8/2017
// Time: 2:35 PM
// Description:
// This ckass implements the advanced control for the PoPUp 
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using Skeletons.Forms;
using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShieldPopUpControl.
	/// </summary>
	public class PopUp : BasicFormSkeleton
	{
		#region #### DECLARATIONS ####
		// Get the Objects
		private static RepoItemInfo TextSpecific = Repo.Wizard.CancelPopUp.AreYouSureTextInfo;
		private static RepoItemInfo ButtonCancelX = Repo.Wizard.CancelPopUp.ButtonCancelXInfo; 
		private static RepoItemInfo ButtonYes = Repo.Wizard.CancelPopUp.ButtonYesInfo; 
		private static RepoItemInfo ButtonNo = Repo.Wizard.CancelPopUp.ButtonNoInfo; 
		private static RepoItemInfo Form = Repo.Wizard.SelfInfo;
		
		#endregion
		
		#region #### CONSTRUCTOR ####		
		public PopUp
			(
				AppSkeleton argApplication,
				EStates argEscape
			) 
			:base
			(
				argApplication,
				Form,
				TextSpecific, 
				ButtonYes,
				ButtonNo,
				ButtonCancelX
			)
		{
			// Assign the States to MyState
			MyState.Proceed.Default = EStates.WizardCompletion;
			MyState.Work.Default = EStates.PopUp;
			MyState.Escape.Default = argEscape;
		}
		#endregion
	}
}