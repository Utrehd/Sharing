﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShield.
	/// </summary>
	public class InstallForms
	{	
		private AppSkeleton application;
				
		public LanguageSelect langaugeSelect;
		
		public Welcome welcome;
		
		public WizardCompleted wizardCompleted;
		
		public LicenseAgreement licenceAgreement;
		
		public CustomerInformation customerInformation;
		
		public SetupType setupType;
		
		public CustomSetup customSetup;
		
		public ReadyToInstall readyToInstall;
		
		public ProgramMaintenance programMaintenance;
		
		public Modify modify;
		
		public ReadyToModify readyToModify;
		
		public ReadyToRemove readyToRemove;
		
		public ReadyToRepair readyToRepair;
		
		
		public InstallForms(AppSkeleton argApplication)
		{
			// Assign App
			application = argApplication;
			
			// Instantiat all Forms and Pass App
			langaugeSelect = new LanguageSelect(application);
			welcome = new Welcome(application);
			wizardCompleted = new WizardCompleted(application);
			licenceAgreement = new LicenseAgreement(application);
			customerInformation = new CustomerInformation(application);
			setupType = new SetupType(application);
			customSetup = new CustomSetup(application);
			readyToInstall = new ReadyToInstall(application);
			programMaintenance = new ProgramMaintenance(application);
			modify = new Modify(application);
			readyToModify = new ReadyToModify(application);
			readyToRemove = new ReadyToRemove(application);
			readyToRepair = new ReadyToRepair(application);
			
			
			
		}
	}
}
