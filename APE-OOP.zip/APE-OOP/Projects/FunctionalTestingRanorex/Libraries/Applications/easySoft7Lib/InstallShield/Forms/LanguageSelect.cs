﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of W01_LanguageSelect.
	/// </summary>
	public class LanguageSelect : InstallBasicForm
	{	
		// Assign Parent Objects
		private static RepoItemInfo TextTitle = Repo.Wizard.LanguageSelect.TextSelectLanguageInfo;
		
		// Assign This Parameters
		private static RepoItemInfo DropDownLanguage = Repo.Wizard.LanguageSelect.DropDownLanguageInfo;
			
		// The Index vars for selecting the language
		private int GermanEntry = 1;
		private int EnglishEntry = 0;	
		
		/// <summary>
		/// Constructor
		/// </summary>
		public LanguageSelect(AppSkeleton argApplication):base(argApplication, TextTitle)
		{
			// Assign My State
			MyState.Entry.Default = EStates.Windows;
			MyState.Escape.Default = EStates.Windows;
			MyState.Proceed.Default = EStates.Welcome;
			MyState.Work.Default = EStates.LanguageSelection;
			
			// Add the existance validations
			validation.ExistItems.Add(DropDownLanguage);
			validation.NoneExistItems.Add(DropDownLanguage);
		}
		
		/// <summary>
		/// This Function Will Open the Language Select, thus also start the exe.
		/// </summary>
		public void Open()
		{
			MyState.Entry.ValidatePoint(); 
			Methods.StartExe(application.SpecificNewestSetupDir);	
			application.State.Current = EStates.LanguageSelection;				
		}
		/// <summary>
		/// Select German Lanague in Drop Down Menu
		/// </summary>
		public void SelectGerman()
		{
			MyState.Work.ValidatePoint();
			Methods.SelectDropDownEntry(DropDownLanguage, GermanEntry);
		}
		/// <summary>
		/// Select English
		/// </summary>
		public void SelectEnglish()
		{
			MyState.Work.ValidatePoint();
			Methods.SelectDropDownEntry(DropDownLanguage, EnglishEntry);
		}
	}
}
