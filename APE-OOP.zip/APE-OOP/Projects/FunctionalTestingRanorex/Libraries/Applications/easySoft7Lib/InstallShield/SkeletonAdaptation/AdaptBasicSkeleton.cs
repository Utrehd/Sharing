﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/8/2017
// Time: 1:59 PM
// Description:
// This Class is implelemting the generic basic control for the installshield 
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using Skeletons.Application;
using SAM;
using easySoft7Lib;
using Skeletons.Forms;

#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShieldControlBasic.
	/// </summary>
	abstract public class InstallBasicForm : BasicFormSkeleton
	{
		#region #### DECLARATIONS ####
		// Assign the Installshield control for the generic stuff
		private static RepoItemInfo ButtonCancelX = Repo.Wizard.General.ButtonCancelXInfo;
		private static RepoItemInfo ButtonProceed = Repo.Wizard.General.ButtonProceedInfo;
		private static RepoItemInfo ButtonCancel = Repo.Wizard.General.ButtonCancelInfo;
		private static RepoItemInfo Form = Repo.Wizard.SelfInfo;
		#endregion
		
		#region #### CONSTRUCTOR ####
		public InstallBasicForm
			(
				AppSkeleton argApplication,
				RepoItemInfo argTextSpecific
			) 
			: base
			(
				// Pass Stuff to Parent
				argApplication,
				Form,
				argTextSpecific,
				ButtonProceed,
				ButtonCancel,
				ButtonCancelX
			)
		{
		}
		#endregion		
	}
}
