﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/23/2017
// Time: 1:18 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;

using SAM;
using Skeletons.Application;
using easySoft7Lib;

#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of ProgramMaintenance.
	/// </summary>
	public class ProgramMaintenance : InstallShieldAdvancedControl
	{	
#region #### DECLARATIONS ####
		private static RepoItemInfo textTitle = Repo.Wizard.ProgramMaintenance.TitleTextInfo;
		private static RepoItemInfo radioButtonModify = Repo.Wizard.ProgramMaintenance.RadioButtonModifyInfo;
		private static RepoItemInfo radioButtonRemove = Repo.Wizard.ProgramMaintenance.RadioButtonRemoveInfo;
		private static RepoItemInfo radioButtonRepair = Repo.Wizard.ProgramMaintenance.RadioButtonRepairInfo;		
#endregion

#region #### CONSTRUCTOR ####

		public ProgramMaintenance(AppSkeleton argApplication):base (argApplication, textTitle)
		{
				MyState.Entry.Default = EStates.Welcome;
				MyState.Escape.Default = EStates.PopUp;
				// has Several Possibilites
				MyState.Proceed.Add(EStates.MaintenanceModify);
				MyState.Proceed.Add(EStates.ReadyToRemove);
				MyState.Proceed.Add(EStates.ReadyToRepair);
				
				MyState.Work.Default = EStates.Maintenance;
				
				validation.ExistItems.Add(radioButtonModify);
				validation.ExistItems.Add(radioButtonRemove);
				validation.ExistItems.Add(radioButtonRepair);
				
				validation.NoneExistItems.Add(radioButtonModify);
				validation.NoneExistItems.Add(radioButtonRemove);
				validation.NoneExistItems.Add(radioButtonRepair);
		}
#endregion

#region #### METHODES ####
		public void SelectModify()
		{	
			// Check the State
			MyState.Work.ValidatePoint();
			// Select the button
			Methods.Click(radioButtonModify);
			Delay.Milliseconds(200);
			// Validate that the other radio Buttons are not selected anymore
			Validate.IsTrue(Repo.Wizard.ProgramMaintenance.RadioButtonModify.Checked);
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonRemove.Checked);
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonRepair.Checked);
			// Change the EState
			MyState.Proceed.Default = EStates.MaintenanceModify;
		}
		
		public void SelectRepair()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			Methods.Click(radioButtonRepair);
			Delay.Milliseconds(200);
			// Validate that the other radio Buttons are not selected anymore
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonModify.Checked);
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonRemove.Checked);
			Validate.IsTrue(Repo.Wizard.ProgramMaintenance.RadioButtonRepair.Checked);
			// Change the EState
			MyState.Proceed.Default = EStates.ReadyToRepair;
		}
		
		public void SelectRemove()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			Methods.Click(radioButtonRemove);
			Delay.Milliseconds(200);
			// Validate that the other radio Buttons are not selected anymore
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonModify.Checked);
			Validate.IsTrue(Repo.Wizard.ProgramMaintenance.RadioButtonRemove.Checked);
			Validate.IsFalse(Repo.Wizard.ProgramMaintenance.RadioButtonRepair.Checked);
			// Change the EState
			MyState.Proceed.Default = EStates.ReadyToRemove;
		}
	
#endregion

	}
}
