﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using StandardForms.Forms;
using Skeletons.Application;
using easySoft7Lib;
#endregion


namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of LicenseAgreement.
	/// </summary>
	public class LicenseAgreement : InstallShieldAdvancedControl
	{		
		// Assign Parent Objects
		private static RepoItemInfo TextTitle = Repo.Wizard.Agreement.TextAgreementInfo;
		
		// Assign This Objects
		private static RepoItemInfo RadioButtonAccept = Repo.Wizard.Agreement.RadioButtonAcceptInfo;
		private static RepoItemInfo RadioButtonNotAccept = Repo.Wizard.Agreement.RadioButtonAcceptInfo;
		private static RepoItemInfo ButtonPrint = Repo.Wizard.Agreement.ButtonPrintInfo;
		
		public Printer printer;
		
		public PopUp popup;
		
		public LicenseAgreement(AppSkeleton argApplication):base (argApplication, TextTitle)
		{
			// Assign the States to the State Class
			MyState.Entry.Default = EStates.Welcome;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.CustomerInformation;
			MyState.Work.Default = EStates.Agreement;
			
			// Pass States to Common Controls
			popup = new PopUp(argApplication, MyState.Work.Default);
			
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
			
			// Add Validations
			validation.ExistItems.Add(RadioButtonAccept);
			validation.ExistItems.Add(RadioButtonNotAccept);
			validation.ExistItems.Add(ButtonPrint);
			validation.NoneExistItems.Add(RadioButtonAccept);
			validation.NoneExistItems.Add(RadioButtonNotAccept);
			validation.NoneExistItems.Add(ButtonPrint);
		}
		
		/// <summary>
		/// This Function Will Open the License Agreement if the entry State is Correct
		/// </summary>
		public void Open()
		{
			// Check State
			MyState.Entry.ValidatePoint();
			// Click Next in order to enter the new window
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			// Validate Stuff Regarding the Screen
			// The Radio Button should be unchecked
			Validate.IsTrue(Repo.Wizard.Agreement.RadioButtonNotAccept.Checked);
			// Validate that the next Button is Disabled
			Validate.IsFalse(Repo.Wizard.General.ButtonProceed.Enabled);
			// Change State to Agreement
			application.State.Current = EStates.Agreement;
		}
		
		/// <summary>
		/// Check the Accept Terms of Condition Button
		/// </summary>
		public void CheckAccept()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Check the Agreement Button
			Methods.Click(Repo.Wizard.Agreement.RadioButtonAcceptInfo);
			Delay.Milliseconds(800);
			// Validate that othaer button changed the state
			Validate.IsFalse(Repo.Wizard.Agreement.RadioButtonNotAccept.Checked);
			// Validate that the next Button is Working now
			Validate.IsTrue(Repo.Wizard.General.ButtonProceed.Enabled);
		}
		
		/// <summary>
		/// This Function will Disagree With the terms of condition
		/// </summary>
		public void CheckNotAccept()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Check the Agreement Button
			Methods.Click(Repo.Wizard.Agreement.RadioButtonNotAcceptInfo);
			Delay.Milliseconds(800);
			// Validate the other Button is has changed
			Validate.IsFalse(Repo.Wizard.Agreement.RadioButtonAccept.Checked);
			// Validate that the next Button is Working now
			Validate.IsFalse(Repo.Wizard.General.ButtonProceed.Enabled);
		}
		
		/// <summary>
		/// This Button Will open the Printers
		/// </summary>
		public void ClickPrint()
		{
						
			// Check the State
			MyState.Work.ValidatePoint();
			// Click the Print Button
			Methods.Click(Repo.Wizard.Agreement.ButtonPrintInfo);
			// Change State
			
			application.State.Current = EStates.Printer;
			// Create new printer
			printer = new Printer(application, MyState.Work.Default);		
		}
	}
}
