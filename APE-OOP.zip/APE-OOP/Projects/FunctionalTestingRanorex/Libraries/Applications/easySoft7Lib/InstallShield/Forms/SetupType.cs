﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion


namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of SetupType.
	/// </summary>
	public class SetupType : InstallShieldAdvancedControl
	{	
		// Assign the Parent Controls
		private static RepoItemInfo titleText = Repo.Wizard.SetupType.TextTitleInfo;
		
		// Assing Controls for this
		private static RepoItemInfo radioButtonComplete = Repo.Wizard.SetupType.RadioButtonCompleteInfo;
		private static RepoItemInfo radioButtonCustom = Repo.Wizard.SetupType.RadioButtonCustomInfo;
		// For the PopUp Window
		public PopUp popup;
		
		public SetupType(AppSkeleton argApplication):base (argApplication, titleText)
		{
			// Assign My State
			MyState.Entry.Default = EStates.CustomerInformation;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.None;
			MyState.Work.Default = EStates.SetupType;
			
			// Pass States to Common Controls
			popup = new PopUp(argApplication, MyState.Work.Default);
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
			
			// Add Validations
			validation.ExistItems.Add(radioButtonComplete);
			validation.ExistItems.Add(radioButtonCustom);
			validation.NoneExistItems.Add(radioButtonComplete);
			validation.NoneExistItems.Add(radioButtonComplete);
		}
		/// <summary>
		/// This Function Will Open the License Agreement if the entry State is Correct
		/// </summary>
		public void Open()
		{
			// Check State
			MyState.Work.ValidatePoint();
			// Click Next in order to enter the new window
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			// Change State to Agreement
			application.State.Current = MyState.Work.Default;
		}
		/// <summary>
		/// Select Complete
		/// </summary>
		public void SelecteComplete()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Check the Agreement Button
			Methods.Click(Repo.Wizard.SetupType.RadioButtonCompleteInfo);
			Delay.Milliseconds(800);
			// Validate that othaer button changed the state
			Validate.IsFalse(Repo.Wizard.SetupType.RadioButtonCustom.Checked);
			// Validate that the next Button is Working now
			Validate.IsTrue(Repo.Wizard.SetupType.RadioButtonComplete.Checked);
			MyState.Proceed.Default = EStates.ReadyToInstall;
		}
		/// <summary>
		/// Select Custom
		/// </summary>
		public void SelecteCustom()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Check the Agreement Button
			Methods.Click(Repo.Wizard.SetupType.RadioButtonCustomInfo);
			Delay.Milliseconds(800);
			// Validate that othaer button changed the state
			Validate.IsFalse(Repo.Wizard.SetupType.RadioButtonComplete.Checked);
			// Validate that the next Button is Working now
			Validate.IsTrue(Repo.Wizard.SetupType.RadioButtonCustom.Checked);
			MyState.Proceed.Default = EStates.CustomSetup;
		}
	}
}
