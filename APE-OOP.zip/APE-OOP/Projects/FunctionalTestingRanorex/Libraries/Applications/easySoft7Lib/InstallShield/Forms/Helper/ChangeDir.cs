﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{		
	/// <summary>
	/// Description of ChangeDir. This is helper control
	/// </summary>
	public class ChangeDir : InstallBasicForm
	{
		private static RepoItemInfo textTitle = Repo.Wizard.ChangeDir.TextTitleInfo;		
		private static RepoItemInfo textBoxFileDir = Repo.Wizard.ChangeDir.TextBoxDirInfo;
		
		public ChangeDir
			(
				AppSkeleton argApplication,
				EStates _Entry
			)
			:base
			(
				argApplication,
				textTitle
			)
		{
			MyState.Entry.Default = _Entry;
			MyState.Escape.Default = _Entry;
			MyState.Proceed.Default = _Entry;
			MyState.Work.Default = EStates.ChangeDir;
			
			// add validation
			validation.ExistItems.Add(textBoxFileDir);
			validation.NoneExistItems.Add(textBoxFileDir);
		}
		/// <summary>
		/// This Function will wirte the value into the text box
		/// </summary>
		/// <param name="_UserName"></param>
		public void WriteDir(string _Dir)
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Write the Value into the TextBoxs
			Methods.TextBoxWrite(textBoxFileDir, _Dir);
		}
	}
}
