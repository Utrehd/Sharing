﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/9/2017
// Time: 1:31 PM
// Description:
// This Class Assigns the Basic EasySoft InstallShield Controls stuff 
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Forms;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShieldFundamentalControl.
	/// </summary>
	abstract public class InstallFundamentalForm : FundamentalFormSkeleton
	{
		#region #### DECLARATIONS ####
		// Assign the Installshield control for the generic stuff
		private static RepoItemInfo ButtonProceed = Repo.Wizard.General.ButtonProceedInfo;
		private static RepoItemInfo ButtonCancel = Repo.Wizard.General.ButtonCancelInfo;
		private static RepoItemInfo Form = Repo.Wizard.SelfInfo;
		#endregion
		
		#region #### CONSTRUCTOR ####
		public InstallFundamentalForm
			(
				AppSkeleton argApplication,
				RepoItemInfo argTextSpecific
			)
			:base
			(
				// Pass the Stuff to Parent
				argApplication,
				Form,
				argTextSpecific,
				ButtonProceed,
				ButtonCancel
			)
		{
		}
		#endregion
	}
}
