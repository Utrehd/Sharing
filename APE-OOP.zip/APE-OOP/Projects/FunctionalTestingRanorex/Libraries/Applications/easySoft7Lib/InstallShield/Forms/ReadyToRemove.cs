﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/27/2017
// Time: 9:28 AM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of Modify.
	/// </summary>
	public class ReadyToRemove : InstallShieldAdvancedControl
	{
		#region #### DECLARATIONS ####
		private static RepoItemInfo textTitle = Repo.Wizard.RemoveTheProgram.TitleTextInfo;
		#endregion
	
		#region #### CONSTRUCTOR ####
		public ReadyToRemove(AppSkeleton argApplication) : base (argApplication, textTitle)
		{
			MyState.Entry.Default = EStates.Maintenance;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.WizardCompletion;
			MyState.Work.Default = EStates.ReadyToRemove;
		}
		#endregion
	}
}
