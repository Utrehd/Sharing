﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion


namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of CustomerInfromation.
	/// </summary>
	public class CustomerInformation : InstallShieldAdvancedControl
	{	
		#region #### DECLARATIONS ####
		// Assign the Objects for Parent
		private static RepoItemInfo SpecificText = Repo.Wizard.CustomerInformation.TextTitleInfo;
		
		// Objects for .this
		private static RepoItemInfo TextBoxUserName = Repo.Wizard.CustomerInformation.UserNameTextInfo;
		private static RepoItemInfo TextBoxOrgainzation = Repo.Wizard.CustomerInformation.OrganizationTextInfo;
		public PopUp popup;
		
		#endregion
		
		#region #### CONSTRUCTOR ####
		public CustomerInformation(AppSkeleton argApplication):base(argApplication, SpecificText)
		{
			// Assign the States to the State Class
			MyState.Entry.Default = EStates.Agreement;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.SetupType;
			MyState.Work.Default = EStates.CustomerInformation;
			
			// Pass States to Common Controls
			popup = new PopUp(argApplication, MyState.Work.Default);
			
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
		}
		#endregion
		
		/// <summary>
		/// This Function Will Open the License Agreement if the entry State is Correct
		/// </summary>
		public void Open()
		{
			// Check State
			MyState.Entry.ValidatePoint();
			// Click Next in order to enter the new window
			Methods.Click(Repo.Wizard.Agreement.RadioButtonAcceptInfo);
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			// Change State to Agreement
			application.State.Current = MyState.Work.Default;
			
			// Add Items to Validation List
			validation.ExistItems.Add(TextBoxUserName);
			validation.ExistItems.Add(TextBoxOrgainzation);
			validation.NoneExistItems.Add(TextBoxUserName);
			validation.NoneExistItems.Add(TextBoxOrgainzation);
		}
		/// <summary>
		/// This Function will wirte the value into the text box
		/// </summary>
		/// <param name="_UserName"></param>
		public void WriteTextBoxUserName(string _UserName)
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Write the Value into the TextBoxs
			Methods.TextBoxWrite(TextBoxUserName, _UserName);
		}
		/// <summary>
		/// This Function will write the value into the text box
		/// </summary>
		/// <param name="_Organization"></param>
		public void WriteTextBoxOrganization(string _Organization)
		{
			// Check the State
			MyState.Work.ValidatePoint();
			// Write the Value into the TextBoxs
			Methods.TextBoxWrite(TextBoxOrgainzation, _Organization);
		}
	}
}
