﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion


namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of InstallShieldCompleted.
	/// </summary>
	public class WizardCompleted : InstallBasicForm
	{	
		//Assign Object for parent
		private static RepoItemInfo TextTitle = Repo.Wizard.Finish.TextWizardCompletedInfo;
		
		public WizardCompleted(AppSkeleton argApplication) : base (argApplication, TextTitle)
		{
			// Assign My states
			MyState.Entry.Default = EStates.None;
			MyState.Escape.Default = EStates.Windows;
			MyState.Proceed.Default = EStates.Windows;
			MyState.Work.Default = EStates.WizardCompletion;
			
			// Add Self to Validation				
			validation.NoneExistItems.Add(form);
		}
		/// <summary>
		/// Validate Installation of Control
		/// </summary>
		public void ValidateInstallation()
		{
			Methods.StartExe(application.ExeDir);
			SAM.Validation.Existence(Repo.easySoft7.SelfInfo);
			Methods.Click(Repo.easySoft7.CloseInfo);
			Delay.Milliseconds(2000);
			SAM.Validation.NoneExistence(Repo.easySoft7.SelfInfo);
		}
		public void ValidateNotInstallation()
		{
			if(File.Exists(application.ExeDir))
			{
			   	Methods.Report(ReportLevel.Failure, "Exe was found");
			}
			else
			{
				Methods.Report(ReportLevel.Success, "Exe does not Exist.");
			}
		}
	}
}
