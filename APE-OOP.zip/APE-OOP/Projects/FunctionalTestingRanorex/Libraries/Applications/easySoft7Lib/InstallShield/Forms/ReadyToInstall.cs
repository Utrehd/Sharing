﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
using easySoft7Lib;
#endregion

namespace easySoft7Lib.InstallShield
{
	/// <summary>
	/// Description of Complete.
	/// </summary>
	public class ReadyToInstall : InstallShieldAdvancedControl
	{	
		// Declare the Parent Control
		public static RepoItemInfo TextTitle = Repo.Wizard.ReadyToInstallTheProgram.TextTitleInfo;
		
		/// <summary>
		/// The PopUp which show if you want to exsit the Menu
		/// </summary>		
		public PopUp popup;
		
		public ReadyToInstall(AppSkeleton argApplication):base (argApplication, TextTitle)
		{
			MyState.Entry.Default = EStates.None;
			MyState.Escape.Default = EStates.PopUp;
			MyState.Proceed.Default = EStates.WizardCompletion;
			MyState.Work.Default = EStates.ReadyToInstall;
			
			popup = new PopUp(argApplication, MyState.Work.Default);
			
			// Do not Validate the escape point. because the window will stay
			ValidateEscapePoint = false;
		}
		/// <summary>
		/// This Metohde will Open this window from the entry state side.
		/// </summary>
		public void Open()
		{
			// Assing the previous State
			if (application.State.Current == EStates.CustomSetup)
			{
				MyState.Entry.Default = application.State.Current;
			}
			else if(application.State.Current == EStates.SetupType)
			{
				MyState.Entry.Default = application.State.Current;
			}
			MyState.Entry.ValidatePoint();
			Methods.Click(Repo.Wizard.General.ButtonProceedInfo);
			application.State.Current= MyState.Work.Default;
		}
	}
}
