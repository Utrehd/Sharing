﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/14/2017
// Time: 10:15 AM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using SAM;
#endregion

namespace Skeletons.Application
{
	/// <summary>
	/// Description of ApplicationState.
	/// </summary>
	public class Point : AppSkeleton
	{
		private List<EStates> states = new List<EStates>();
		
		public EStates Default {
			get 
			{ return GetState(); }
			set 
			{ states.Insert(0, value); }
		}
		
		/// <summary>
		/// Add a new State to the list
		/// </summary>
		/// <param name="_state"></param>
		public void Add(EStates _state)
		{
			states.Add(_state);
		}
		
		/// <summary>
		/// Will give back a exact State. If not overloaded with index 0
		/// </summary>
		/// <param name="_Index"></param>
		public EStates GetState(int _Index = 0)
		{
			return states[_Index];
		}
		
		/// <summary>
		/// Get the List of States
		/// </summary>
		/// <returns></returns>
		public List<EStates> Get()
		{
			return states;
		}
		
		/// <summary>
		/// Set the List of States
		/// </summary>
		/// <param name="_list"></param>
		public void Set(List<EStates> _list)
		{
			states = _list;
		}
		
		/// <summary>
		/// This Function will look for the req state in the point and return true if found
		/// </summary>
		/// <param name="_ReqState"></param>
		/// <returns></returns>
		public bool Contains(EStates _ReqState)
		{
			foreach (EStates state in states)
			{
				if (_ReqState == state)
				{
					// Logger.LogInfo("State: " + _ReqState.ToString() + " was found in Point: " + state.ToString());
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// This Function Will Test if the Current state is equal to of the contained States of the point
		/// </summary>
		/// <param name="_ReqState"></param>
		public void ValidatePoint()
		{
			// Start Logging
			Logger.LogUnderTitle("State Validation");
			Logger.LogInfo("Search for the current State: (" + State.Current.ToString() + ") in the Point");
			
			if(states.Contains(State.Current))
			{
				LogStates();
				Logger.LogNewLine();
				Logger.LogSucess("State: (" + State.Current.ToString() + ") was found in Point");
			}
			else if(states.Contains(EStates.None))
			{
				LogStates();
				Logger.LogNewLine();
				Logger.LogInfo("State: (" + State.Current.ToString() + ") was Not found in Point");
			}
			else if (!(states.Contains(State.Current)))
			{
				LogStates();
				Logger.LogNewLine();
				Logger.LogInfo("State: (" + State.Current.ToString() + ") was NOT found in the Point");
			}
		} 
		
		public void LogStates()
		{
			Logger.LogInfo("List All States in this Point:");
			foreach (EStates state in states)
			{
				Logger.LogInfo("State: " + state.ToString());
			}
		}
	}
}
