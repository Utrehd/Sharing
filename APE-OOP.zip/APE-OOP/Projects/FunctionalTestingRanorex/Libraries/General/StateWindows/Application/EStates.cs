﻿/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/29/2017
 * Time: 2:48 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Skeletons.Application
{
	/// <summary>
	/// Description of EStates.
	/// </summary>
		public enum EStates
		{
			ChangeDir, 				// ChangeCurrentDestinationDir
			CustomSetup,  			// The Custom SetupState
			ReadyToInstall,			// Ready to Install State
			SetupType, 				// The Customer Infromation Mask
			SaveAsConfirm,		 	// Confrim the Save As if file already exsits
			SaveAs,				 	// State for the Save As Windwo
			Printer,			 	// The Stae for the Printer
			
			
			
			// All the PopUps
			PopUp,
			
			None,				 	// Use this if there is no Value
			Windows, 			 	// The Windows State
			LanguageSelection,   	// The Langauge select mask in installshield
			Welcome,  			 	// The Second installShield Window
			Agreement,			 	// The Agreement Window
			CustomerInformation, 	// Customer Infromation Window
			WizardCompletion, 		// For the Wizard Complition Window

			Maintenance,
			ReadyToRemove,
			ReadyToRepair,
			MaintenanceModify,
			ReadyToModify,
						
			
		};
}