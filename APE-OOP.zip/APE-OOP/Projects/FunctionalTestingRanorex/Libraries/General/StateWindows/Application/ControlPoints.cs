﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/14/2017
// Time: 10:23 AM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using SAM;
#endregion

namespace Skeletons.Application
{
	/// <summary>
	/// Description of ApplicationStates.
	/// </summary>
	public class ControlPoints
	{
		Point entry = new Point();
		
		public Point Entry {
			get { return entry; }
			set { entry = value; }
		}
		
		Point work = new Point();
		
		public Point Work {
			get { return work; }
			set { work = value; }
		}
		
		Point procees = new Point();
		
		public Point Proceed {
			get { return procees; }
			set { procees = value; }
		}
		
		Point escape = new Point();
		
		public Point Escape {
			get { return escape; }
			set { escape = value; }
		}
	}
}
