﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/14/2017
// Time: 11:37 AM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using SAM;
#endregion

namespace Skeletons.Application
{
	/// <summary>
	/// Description of ApplicationState.
	/// </summary>
	public class ApplicationState
	{
		/// <summary>
		/// Event
		/// </summary>
		public event EventState _StateChanged;
		
		EStates current;
		
		/// <summary>
		/// Contains the Current State
		/// </summary>
		public EStates Current {
			get { return current; }
			set 
			{
				Logger.CreateNew("Change Application State");
				
				// Assign old state to the last
				last = current;
				
				// Assign the new state to the current state
				current = value;
				
				// Add new state to History
				History.Add(current);
				
				Logger.LogInfo("State Changed from: " + last.ToString() + " to " + current.ToString());
				
				Logger.LogNewLine();
				
				//Log History of State
				Logger.LogInfo("History:");
				LogHistory();
				Logger.LogNewLine();
				
				// Trigger the Validation Event
				Logger.LogInfo("Trigger Validation Event");
				Logger.ReportLog();
				_StateChanged.Invoke();
			}
		}
		
		EStates last;
		
		/// <summary>
		/// Contains the Last State
		/// </summary>
		public EStates Last {
			get { return last; }
		}
		
		List<EStates> history = new List<EStates>();
		
		/// <summary>
		/// A List containing all States done in this instance
		/// </summary>
		public List<EStates> History {
			get { return history; }
			set { history = value; }
		}
		
		/// <summary>
		/// Will Print the History of the Application States
		/// </summary>
		public void LogHistory()
		{
			foreach (EStates state in History)
			{
				Logger.LogInfo("State: " + state.ToString());
			}
		}
	}
}
