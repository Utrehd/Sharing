﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using SAM;
#endregion

namespace Skeletons.Application
{
	public delegate void EventState();
	
	/// <summary>
	/// Description of _MasterParent.
	/// </summary>
	abstract public class AppSkeleton
	{
		#region Initlaizations
		
		/// <summary>
		/// The Application State
		/// </summary>
		public ApplicationState State = new ApplicationState();
		
		/// <summar>
		/// This Dir Descirbes the General Path to all Dirs on which ranorex is working on
		/// </summary>
		public string WorkDir { get; set; }
		
		private string newBuildDir;
		/// <summary>
		/// This is the Path to the Build Folder where Boon is Saving their new Builds
		/// </summary>
		public string NewBuildDir { get{return newBuildDir;} }		
		/// <summary>
		/// The Dir to all the Build Setups
		/// </summary>
		public string SetupDirs { get{return WorkDir + @"\Setups";}}
		
		private string specificSetupDir;
		/// <summary>
		/// The Dir to the Setup
		/// </summary>
		public string SpecificNewestSetupDir 
		{
			get
			{
				if (specificSetupDir == null)  // If there is no Path yet get the newest version form the setupDir
				{
					specificSetupDir = Methods.GetNewestDir(SetupDirs);
				}
				return specificSetupDir + SetupExeName;
			}
			set{specificSetupDir = value;}
		}
		
		private string setupExeName;
		/// <summary>
		/// Name of the SetupExe
		/// </summary>
		public string SetupExeName { get{return setupExeName;} }
		
		private string exeName;
		/// <summary>
		/// The Name of the Installed EasySoft Exe
		/// </summary>
		public string ExeName { get{return exeName;} }
		/// <summary>
		/// The Directroy to the EasySoft Exe
		/// </summary>
		public string ExeDir { get{return WorkDir + @"\Program" + ExeName;} }
		#endregion
		
		public void SetParameters(string argNewBuildDir, string argSetupExeName, string argExeName)
		{
			newBuildDir = argNewBuildDir;
			setupExeName = argSetupExeName;
			exeName = argExeName;
		}
		
		/// <summary>
		/// This Function will copy the most recent easy build to the destination dir.
		/// </summary>
		/// <param name="_DestinationDir"></param>
		public void CopyNewestBuild ()
		{
			SpecificNewestSetupDir = Methods.GetRecentBuildAndCopy(SetupDirs, NewBuildDir);
		}
		/*
		/// <summary>
		/// This Function will choose the most recent easy installation in the destinationDir
		/// </summary>
		/// <param name="_DestinationDir"></param>
		public void UseNewestEasy(string _DestinationDir)
		{
			SpecificSetupDir = Basic.GetNewestDir(SetupDirs);
		}*/
		
		public void SetWorkgDir(string _WorkDir)
		{
			WorkDir = _WorkDir;
		}
		
		public void DeleteWorkDir()
		{
			Methods.DeleteDirectory(WorkDir);
		}
	}
}
