﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/7/2017
// Time: 3:55 PM
// Description:
// This Class shall implements i used as a skeletong fpr creating real forms
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
#endregion


namespace Skeletons.Forms
{
	/// <summary>
	/// Description of CommonControlsAdanvced.
	/// </summary>
	abstract public class AdvancedFormSkeleton : BasicFormSkeleton
	{	
		#region #### DECLARATIONS ####
		/// <summary>
		/// The Window Frame
		/// </summary>
		RepoItemInfo ButtonBack;
		#endregion
				
		#region #### CONSTRUCTOR ####
		/// <summary>
		/// This Form Implements a Basic From + A back button
		/// </summary>
		/// <param name="argApplication"></param>
		/// <param name="argForm"></param>
		/// <param name="argTextSpcific"></param>
		/// <param name="argButtonProceed"></param>
		/// <param name="argButtonCancel"></param>
		/// <param name="argButtonCancel2"></param>
		/// <param name="argButtonBack"></param>
		public AdvancedFormSkeleton
			(
				AppSkeleton argApplication,
				RepoItemInfo argForm,
				RepoItemInfo argTextSpcific,
				RepoItemInfo argButtonProceed, 
				RepoItemInfo argButtonCancel, 
				RepoItemInfo argButtonCancel2,
				
				// The Other Objects which are implemented in this form and not in the parent
				RepoItemInfo argButtonBack
				
			) 
			:base 
			(
				// Pass the Stuff to the Parent Form
				argApplication,
				argForm,
				argTextSpcific,
				argButtonProceed,
				argButtonCancel,
				argButtonCancel2
			)
		{
			ButtonBack = argButtonBack;
			validation.ExistItems.Add(ButtonBack);
		}
		#endregion
		
		#region #### METHODES ####
		/// <summary>
		/// Will Click the Back Button
		/// </summary>
		public void ClickBack()
		{	
			MyState.Work.ValidatePoint();
			Methods.Click(ButtonBack);
			
			application.State.Current = MyState.Entry.Default;
		}
		#endregion
	}
}
