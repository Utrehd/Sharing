﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/7/2017
// Time: 3:55 PM
// Description:
// This Class Implements some basic controls which all kinds of Windows do share.
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using SAM;
using Skeletons.Application;
#endregion

namespace Skeletons.Forms
{
	/// <summary>
	/// Description of CommonControls.
	/// </summary>
	abstract public class BasicFormSkeleton : FundamentalFormSkeleton
	{
		#region #### DECLARATIONS ####
		/// <summary>
		/// The Window Frame
		/// </summary>
		RepoItemInfo ButtonCancel2;
		#endregion
		
		#region #### CONSTRUCTOR ####
		public BasicFormSkeleton
			(
				// The Application containing all other Forms
				AppSkeleton argApplication,
				// The Window Form itself
				RepoItemInfo argForm,
				// The Specific Text, usualy a title or something
				RepoItemInfo argTextSpecific,
				// The Proceed Button is usualy a yes, ok, install button				
				RepoItemInfo argButtonProceed,
				// The cancel button which can be an X in the top right Corner or such
				RepoItemInfo argButtonCancel,
				
				// The Remaining Objects for This Particualr Form				
				RepoItemInfo argButtonCancel2

			) 
			:base 
			(
				// Pass the parameters to the Parent Form
				// App
				argApplication: argApplication,
				// Form
				argForm: argForm,
				// Text
				argTextSpecific: argTextSpecific,
				// Proceed
				argButtonProceed: argButtonProceed,
				// Cancel
				argButtonCancel: argButtonCancel
			)
		{
			ButtonCancel2 = argButtonCancel2;
			
			// Add To Exists Validation
			validation.ExistItems.Add(ButtonCancel2);
		}
		#endregion		
		
		#region #### METHODES ####
		/// <summary>
		/// Will Click the CancelX Button
		/// </summary>
		public void ClickCancel2()
		{			
			MyState.Work.ValidatePoint();
			Methods.Click(ButtonCancel2);
			
			application.State.Current = MyState.Escape.Default;
		}
		#endregion
	}
}
