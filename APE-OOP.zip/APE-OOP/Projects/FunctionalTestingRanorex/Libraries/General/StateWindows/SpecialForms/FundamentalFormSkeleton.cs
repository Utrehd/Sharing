﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/7/2017
// Time: 3:55 PM
// Description:
// This Class shall be the basic of all controls = a control is usualy a basic window or screen of the software. 
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using Skeletons.Application;
using SAM;
#endregion

namespace  Skeletons.Forms
{
	/// <summary>
	/// Description of ControlFundamental.
	/// </summary>
	abstract public class FundamentalFormSkeleton
	{
		#region #### DECLARATIONS ####
		/// <summary>
		/// The Application Referenced
		/// </summary>
		public AppSkeleton application;

		/// <summary>
		/// The State Definitions of the control
		/// </summary>
		protected ControlPoints MyState = new ControlPoints();
		
		public SAM.Validation validation = new SAM.Validation();
		
		/// <summary>
		/// The Window Frame
		/// </summary>
		protected RepoItemInfo form;
		
		/// <summary>
		/// The Cancel Button
		/// </summary>
		protected RepoItemInfo buttonCancel;
		
		/// <summary>
		/// The Cancel Button
		/// </summary>
		protected RepoItemInfo textSpecific;
		
		/// <summary>
		/// The Cancel Button
		/// </summary>
		protected RepoItemInfo buttonProceed;
		
		bool validateEntryPoint = true;
		
		/// <summary>
		/// Validates the Entry Point : Default is true
		/// </summary>
		public bool ValidateEntryPoint {
			get { return validateEntryPoint; }
			set { validateEntryPoint = value; }
		}
		
		bool validateWorkPoint = true;
		
		/// <summary>
		/// Validates the Work Point : Default is true
		/// </summary>
		public bool ValidateWorkPoint {
			get { return validateWorkPoint; }
			set { validateWorkPoint = value; }
		}
		
		bool validateEscapePoint = true;
		
		/// <summary>
		/// Validates the Escape Point : Default is true
		/// </summary>
		public bool ValidateEscapePoint {
			get { return validateEscapePoint; }
			set { validateEscapePoint = value; }
		}
		
		bool validateProceedPoint = true;
		/// <summary>
		/// Validates the Proceed Point : Default is true
		/// </summary>
		public bool ValidateProceedPoint {
			get { return validateProceedPoint; }
			set { validateProceedPoint = value; }
		}
		
		#endregion
		
		#region #### CONSTRUCTOR ####
		/// <summary>
		/// Constructor For FundamentalForm which is the lowest level of a Form concept
		/// </summary>
		/// <param name="argApplication"></param>
		/// <param name="argWindow"></param>
		/// <param name="argTextSpecific"></param>
		/// <param name="argButtonProceed"></param>
		/// <param name="argButtonCancel"></param>
		/// <param name="?"></param>
		public FundamentalFormSkeleton
			(
				// The Application containing all other Forms
				AppSkeleton argApplication,
				// The Window Form itself
				RepoItemInfo argForm,
				// The Specific Text, usualy a title or something
				RepoItemInfo argTextSpecific,
				// The Proceed Button is usualy a yes, ok, install button				
				RepoItemInfo argButtonProceed,
				// The cancel button which can be an X in the top right Corner or such
				RepoItemInfo argButtonCancel
			)
		{
			// Assign App
			application = argApplication;
			
			// Assign the AdapterInfos
			buttonProceed = argButtonProceed;
			buttonCancel = argButtonCancel;
			form = argForm;
			textSpecific = argTextSpecific;
			
			
			// Add Items to the Validation List
			validation.ExistItems.Add(form);
			validation.ExistItems.Add(textSpecific);
			validation.ExistItems.Add(buttonProceed);
			validation.ExistItems.Add(buttonCancel);
			
			validation.NoneExistItems.Add(textSpecific);
			
			// Assign the Validation Trigger to the Event StateChanged
			// Remove exsiting subscribtions
			application.State._StateChanged -= TriggerValidation;
			// Subscribe again
			application.State._StateChanged += TriggerValidation;
		}
		#endregion
		
		#region #### METHODES ####
		
		/// <summary>
		/// Will Click the Cancel Button
		/// </summary>
		public void ClickCancel()
		{
			MyState.Work.ValidatePoint();
			Methods.Click(buttonCancel);
			
			application.State.Current = MyState.Escape.Default;
		}
		/// <summary>
		/// Will Click the OK or Next Button
		/// </summary>
		public void ClickProceed()
		{
			// Check the State
			MyState.Work.ValidatePoint();
			
			// Click
		 	Methods.Click(buttonProceed);
		 	
		 	application.State.Current = MyState.Proceed.Default;
		}

		/// <summary>
		/// This Will Select the appropated Validation depending on the current state
		/// </summary>
		private void TriggerValidation()
		{
			Logger.CreateNew("Validation");
			
			Logger.LogInfo("The Validation of : (" + this.GetType().Name + ") as calling class was triggered");
			
			if(MyState.Entry.Contains(application.State.Current) & ValidateEntryPoint)
			{
				//MyState.Entry.ReportStates();
				validation.NoneExistenceAll();
			}
			else if(MyState.Proceed.Contains(application.State.Current) & ValidateProceedPoint)
			{
				//MyState.Entry.ReportStates();
				validation.NoneExistenceAll();    	
	        }
			else if(MyState.Escape.Contains(application.State.Current) & ValidateEscapePoint)
			{
				//MyState.Entry.ReportStates();
				validation.NoneExistenceAll(); 	
	        }
			else if(MyState.Work.Contains(application.State.Current) & ValidateWorkPoint)
			{
				//MyState.Entry.ReportStates();
				validation.ExistenceAll();
			}
			else
			{
				Logger.ClearLog();
				return;
			}
			Logger.ReportLog();
		}
		#endregion
	}
}
