﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 7/10/2017
// Time: 12:07 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

namespace Skeletons.Controls
{
	/// <summary>
	/// Description of ControlSkeleton.
	/// </summary>
	public class ControlSkeleton
	{
		public ControlSkeleton()
		{
		}
	}
}
