﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;

using StandardForms.Repos;
using Skeletons.Forms;
using Skeletons.Application;
using SAM;
#endregion


namespace StandardForms.Forms
{
	/// <summary>
	/// Description of SaveAs.
	/// </summary>
	public class SaveAs : BasicFormSkeleton
	{	
		// Get the Objects
		private static RepoItemInfo TextSpecific = Rep.SaveAs.TitleBarSaveTheFileAsInfo;
		private static RepoItemInfo ButtonCancelX = Rep.SaveAs.ButtonCancelXInfo; 
		private static RepoItemInfo ButtonSave = Rep.SaveAs.ButtonSaveInfo; 
		private static RepoItemInfo ButtonCancel = Rep.SaveAs.ButtonCancelInfo; 
		private static RepoItemInfo Form = Rep.SaveAs.SelfInfo;
		private static RepoItemInfo TextBoxFileName = Rep.SaveAs.FileNameTextBoxInfo;
		
		/// <summary>
		/// Confrim The Save As if the file is already exsiting
		/// </summary>
		public ConfirmSaveAs confirmSaveAs;
		
		/// <summary>
		/// Constructor, Asks for EntryPoint State, Can usualy be seen as the Workpoint
		/// </summary>
		/// <param name="_EntryPoint"></param>
		public SaveAs
			(
				AppSkeleton argApplication,
				EStates _Entry,
				EStates _Escape
			) 
			:base
			(
				argApplication,
				Form,
				TextSpecific,
				ButtonSave,
				ButtonCancel,
				ButtonCancelX
			)
		{
			MyState.Entry.Default = _Entry;
			MyState.Escape.Default = _Escape;
			MyState.Proceed.Default = _Escape;
			MyState.Work.Default = EStates.SaveAs;
		}
		
		public void WriteTextBoxFileName (string _text)
		{
			MyState.Work.ValidatePoint();
			
			// Try To save File
			Methods.TextBoxWrite(TextBoxFileName, _text);
		}
		
		/// <summary>
		/// This Function Will Save the File in the specified Datapath
		/// </summary>
		public void Save(string _DestinationDir, string _FileName, bool _OverwirteSave = true)
		{
			MyState.Work.ValidatePoint();
			
			string fileDir = _DestinationDir + _FileName;			
			
			// Check Exsitance of old file with same name
			bool alreadyExsits = false;
			
			if(File.Exists(fileDir))
			{
				alreadyExsits = true;
			}
			
			// Try To save File
			WriteTextBoxFileName(fileDir);
			Methods.Click(ButtonSave);
			
			Delay.Milliseconds(2000);
			// Decide the Action if an old File Exsits
			if(alreadyExsits)
			{
				application.State.Current = EStates.SaveAsConfirm;
				confirmSaveAs = new ConfirmSaveAs(application, MyState.Work.Default, MyState.Proceed.Default);

				if(_OverwirteSave)
				{
					confirmSaveAs.ClickProceed();
				}
				else
				{
					confirmSaveAs.ClickCancel();
				}
			}
			else
			{
				// Change State to leaving point
				application.State.Current = MyState.Proceed.Default;
			}
			
			if(File.Exists(fileDir))
			{
				Methods.Report(ReportLevel.Success, "File was found");
			}
			else
			{
				Methods.Report(ReportLevel.Failure, "File was not found");
			}
		}
	}
}
