﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using Skeletons.Application;
using Skeletons.Forms;
using StandardForms.Repos;

#endregion



namespace StandardForms.Forms
{
	/// <summary>
	/// Description of ConfrimSaveAs.
	/// </summary>
	public class ConfirmSaveAs : FundamentalFormSkeleton
	{
		private static RepoItemInfo TextSpecific = Rep.ConfirmSaveAs.ContentTextInfo;
		private static RepoItemInfo ButtonYes = Rep.ConfirmSaveAs.ButtonYesInfo;
		private static RepoItemInfo ButtonNo = Rep.ConfirmSaveAs.ButtonNoInfo;
		private static RepoItemInfo Form = Rep.ConfirmSaveAs.SelfInfo;
		
		//private static RepoItemInfo Button
		/// <summary>
		/// Constructor, Asks for EntryPoint State, Can usualy be seen as the Workpoint
		/// </summary>
		/// <param name="_EntryPoint"></param>
		public ConfirmSaveAs
			(
				AppSkeleton argApplication,
				EStates _EntryPoint,
				EStates _LeavingPoint
			)
			:base
			(	
				argApplication,	
				Form,
				TextSpecific,
				ButtonYes,
				ButtonNo
			)
		{
			
			// Assign the States to MyState
			MyState.Entry.Default = _EntryPoint;
			MyState.Escape.Default = _EntryPoint;
			MyState.Proceed.Default = _LeavingPoint;
			MyState.Work.Default = EStates.SaveAsConfirm;
		}
	}
}
