﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using Skeletons.Application;

using StandardForms.Repos;
using Skeletons.Forms;
using SAM;

#endregion


namespace StandardForms.Forms
{
	/// <summary>
	/// Description of Printer.
	/// </summary>
	public class Printer : BasicFormSkeleton
	{	
		// Assign the Basic Items		
		private static RepoItemInfo TextSpecific = Rep.Printer.TextStatusInfo;
		private static RepoItemInfo ButtonCancelX = Rep.Printer.ButtonCancelXInfo; 
		private static RepoItemInfo ButtonPrint = Rep.Printer.ButtonPrintInfo; 
		private static RepoItemInfo ButtonCancel = Rep.Printer.ButtonCancelInfo; 
		private static RepoItemInfo Form = Rep.Printer.SelfInfo;
		private static RepoItemInfo PrinterXPS = Rep.Printer.MicrosoftXPSDocumentWriterInfo;
	
		public SaveAs saveAs;
		
		/// <summary>
		/// Constructor, Asks for EntryPoint State, Can usualy be seen as the Workpoint
		/// </summary>
		/// <param name="_EntryPoint"></param>
		public Printer
			(
				AppSkeleton argApplication,
				EStates _EntryPoint
			) 
			:base
			(
				argApplication,
				Form,
				TextSpecific,
				ButtonPrint, 
				ButtonCancel,
				ButtonCancelX 
			)
		{
			MyState.Entry.Default = _EntryPoint;
			MyState.Escape.Default = _EntryPoint;
			MyState.Proceed.Default = EStates.SaveAs;
			MyState.Work.Default = EStates.Printer;
		}
		/// <summary>
		/// This Function Will Cancel
		/// </summary>
		public void SelectXPSDocumentWriter()
		{
			MyState.Work.ValidatePoint();
			//SAM.Click(Repo.Printer.MicrosoftXPSDocumentWriter.Select);
			//CurrentState = MyState.Proceed;
			Rep.Printer.MicrosoftXPSDocumentWriter.Select();
			// Create new Save as
			saveAs = new SaveAs(application, MyState.Work.Default, MyState.Entry.Default);
		
			// Add Item to Validation
			validation.ExistItems.Add(PrinterXPS);
			validation.NoneExistItems.Add(PrinterXPS);
		}
	}
}
