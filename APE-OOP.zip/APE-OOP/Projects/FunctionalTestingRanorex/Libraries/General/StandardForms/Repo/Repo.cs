﻿/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 3:56 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Ranorex.Core.Repository;
using StandardForms.Repo;

namespace StandardForms.Repos
{
	/// <summary>
	/// Description of Repo.
	/// </summary>
	public static class Rep
	{		
			// Assign Reprository Instance to Repo.Printer
			public static RepositoryFolders.PrintAppFolder Printer = Repository.Instance.Print;

			// Assign Reprository Instance to Repo.SaveAs
			public static RepositoryFolders.SaveAsAppFolder SaveAs = Repository.Instance.SaveAs;

			// Assign Reprository Instance to Repo.SaveAs
			public static RepositoryFolders.ConfirmSaveAsAppFolder ConfirmSaveAs = Repository.Instance.ConfirmSaveAs;
	}
}
