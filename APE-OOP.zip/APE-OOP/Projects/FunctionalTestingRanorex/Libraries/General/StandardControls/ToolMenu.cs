﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 7/10/2017
// Time: 12:11 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
using SAM;
#endregion


namespace StandardControls
{
	//RepoItemInfo menuButton;
	
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class ToolMenu
	{
		private Ranorex.MenuItem menu;

		public ToolMenu(Ranorex.MenuItem argMenuButton)
		{
			menu = argMenuButton;
		}
		
		public void OpenMenu()
		{
			menu.Click();
		}
	}
}