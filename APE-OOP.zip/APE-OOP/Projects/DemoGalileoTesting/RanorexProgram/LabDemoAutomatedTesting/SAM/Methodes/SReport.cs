﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// Will Generate a Proper Report ala SAM
		/// </summary>
		/// <param name="level"></param>
		/// <param name="message"></param>
		public static void Report(ReportLevel _Level, string _Message)
		{
			// Get call stack
			StackTrace stackTrace = new StackTrace();

			// Get calling method name
			string lastMetohde = stackTrace.GetFrame(1).GetMethod().Name + ": ";

			// Make Report
			Ranorex.Report.Log(_Level, lastMetohde + _Message);
			
			// Abort Ranorex in case of error
			if (_Level == ReportLevel.Failure)
			    {
			    //	Validate.();
			    }
		}
		
		public static void ReportNewLine()
		{
			// Get call stack
			StackTrace stackTrace = new StackTrace();
			
			// Get calling method name
			string lastMetohde = stackTrace.GetFrame(1).GetMethod().Name + ": ";
			
			Ranorex.Report.Log(ReportLevel.Info, lastMetohde.PadRight(38, '-'));
		}
		public static void ReportEndLine()
		{
			string message = "";
			Ranorex.Report.Log(ReportLevel.Info, message.PadRight(38, '-'));
		}
	}
	
}

