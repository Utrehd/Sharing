﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		public static string GetNewestDir(string _TargeDir)
		{
			Logger.CreateNew("Find The Newest Directory");
			Logger.LogInfo("Target Directory: " + _TargeDir);
			
			// Get Recent build Name from sourcepath
        	var directory = new DirectoryInfo(_TargeDir);
			var myFile = directory.GetDirectories().OrderByDescending(f => f.LastWriteTime).First();
			Logger.LogInfo("Found Directory: " + myFile.ToString());
			
			// Create string of recent build with source path
			string NewestDir = Path.Combine(_TargeDir, myFile.ToString());
			Logger.LogInfo("Source Path: " + NewestDir.ToString());
			Logger.ReportLog();
			return NewestDir;
		}
	}
}
