﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/9/2017
// Time: 12:25 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// This Function Will Select the required entry of an combox
		/// </summary>
		/// <param name="_DropDownControl" Needs to be an combox></param>
		/// <param name="_Entry"></param>
		public static void SelectDropDownEntry(RepoItemInfo _DropDownControl, int _Entry)
		{
			// Create an adapter
			Ranorex.ComboBox dropDownControl;
			
			// Assign Adapter to Combox control
			dropDownControl = _DropDownControl.CreateAdapter<Ranorex.ComboBox>(true);
			
			// Select the Entry
			dropDownControl.Items[_Entry].Select();
		}
	}
}
