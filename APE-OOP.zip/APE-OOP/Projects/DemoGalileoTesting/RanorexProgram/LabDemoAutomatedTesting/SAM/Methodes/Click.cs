﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Runtime.InteropServices;
using System.Timers;
using System.Diagnostics;
#endregion

namespace SAM
{
	public partial class Methods
	{	
		
		/// <summary>
		/// The Proper Click Implementation for RepoInfoTimes
		/// </summary>
		/// <param name="_adapter"></param>
		/// <param name="_TimeOut = 500ms"></param>
		public static void Click(RepoItemInfo _Item, int _Delay = 50, int _TimeOut = 5000)//Ranorex.Button _Button, Ranorex.Text _Text)
		{
			// Sam Report that it tries to click
			Logger.CreateNew("Click");
			Logger.LogClass();
			Logger.LogMethod();
			Logger.LogInfo("Try to click: " + _Item.FullName);

			// Create temp values and assign parameters
			Adapter adapter;
			adapter = _Item.CreateAdapter<Unknown>(true);
			string reportMessage = _Item.FullName;
			
			// Pass Parameters to function
			ClickAdapter(adapter, reportMessage, _Delay , _TimeOut);
			Logger.ReportLog();
		}
		/// <summary>
		/// This Function Will Click the Adapter
		/// </summary>
		/// <param name="_Adapter"></param>
		/// <param name="_ReportMessage"></param>
		/// <param name="_TimeOut = 500ms"></param>
		private static void ClickAdapter(Ranorex.Adapter _Adapter, string _ReportMessage, int _Delay = 50, int _TimeOut = 5000)
		{
			// Create StopWatch
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			
			// While stop watch did not reach the timeout
			while(stopwatch.ElapsedMilliseconds < _TimeOut)
			{
				// when the adapter is clickable
				if(_Adapter.Enabled && _Adapter.Visible)
				{
					// Run the Delya function
					Delay.Milliseconds(_Delay);
					// Click adapter
					Mouse.Click(_Adapter);
					
					// Make a report
					Logger.LogSucess("Click Scucessfull");
					
					
					// Reset and Return
					stopwatch.Stop();
					stopwatch.Reset();
					return;
				}
			}
			
			// if adaper wasent clicked than there is an timeout.
			Ranorex.Report.Screenshot();
			Logger.LogFailure("Click Faild");
		}
	}
}