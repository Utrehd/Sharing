﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Diagnostics;
using System.Management;
#endregion

namespace SAM
{	
	public class Validation
	{	
		/// <summary>
		/// The List of all Items which have to be validated
		/// </summary>
		public List<RepoItemInfo> ExistItems = new List<RepoItemInfo>();
		
		/// <summary>
		/// The List of all Items which have to be validated
		/// </summary>
		public List<RepoItemInfo> NoneExistItems = new List<RepoItemInfo>();
			
		/// <summary>
		/// This function will validate the exsitence of all Items in the list
		/// </summary>
		/// <param name="argDelay"></param>
		public void ExistenceAll(int argDelay = 2000)
		{
			Delay.Milliseconds(argDelay);
			foreach (RepoItemInfo item in ExistItems)
			{
				Existence(item, 100, 30000);
			}
		}
			
		/// <summary>
		/// This will Validate all items in the list which taht they are not exsiting
		/// </summary>
		/// <param name="argDelay"></param>
		public void NoneExistenceAll(int argDelay = 3000)
		{
			Delay.Milliseconds(argDelay);
			foreach (RepoItemInfo item in NoneExistItems)
			{
				NoneExistence(item, 100, 500);
			}
		}
		/// <summary>
		/// Validates of the given Object is exsiting - Enabled, Valid & Visible
		/// </summary>
		/// <param name="_Adapter"></param>
		/// <param name="_Delay"></param>
		/// <param name="_Timeout"></param>
		public static void Existence(RepoItemInfo _Item, int _Delay = 500, int _Timeout = 30000)
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			Logger.LogUnderTitle("Validate Exsitance");
			
			Logger.LogInfo("Item: " + _Item.FullName);
			//Logger.LogInfo("Item Path: " + _Item.AbsolutePath);
			Logger.LogInfo("Timeout: " + _Timeout);
			// Do Delay
			Delay.Milliseconds(_Delay);
			
			// if Object meets all this requirements
			if(_Item.Exists(_Timeout))
			{
				Logger.LogInfo("Elapsed Time: " + stopwatch.ElapsedMilliseconds);
				Logger.LogSucess("Item does Exist");
			}
			else
			{
				Logger.LogInfo("Elapsed Time: " + stopwatch.ElapsedMilliseconds);
				Ranorex.Report.Screenshot();
				Logger.LogFailure("Item Does Not Exist");
			}
		}
		
		/// <summary>
		/// Validates if given object is not exsiting - Enabled, Valid or Visible
		/// </summary>
		/// <param name="_Adpater"></param>
		/// <param name="_Delay"></param>
		/// <param name="_Timeout"></param>
		public static void NoneExistence(RepoItemInfo _Item, int _Delay = 500, int _Timeout = 2000)
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			
			Logger.LogUnderTitle("Validate Not Exsitance");
			
			Logger.LogInfo("Item: " + _Item.FullName);
			//Logger.LogInfo("Item Path: " + _Item.AbsolutePath);
			Logger.LogInfo("Timeout: " + _Timeout);
			
			Delay.Milliseconds(_Delay);
			if(_Item.Exists(_Timeout))
			{
				Logger.LogInfo("Elapsed Time: " + stopwatch.ElapsedMilliseconds);
				Ranorex.Report.Screenshot();
				Logger.LogFailure("Item Does Exist");
			}
			else
			{
				Logger.LogInfo("Elapsed Time: " + stopwatch.ElapsedMilliseconds);
				Logger.LogSucess("Item Does Not Exist");
			}
		}
	}
}