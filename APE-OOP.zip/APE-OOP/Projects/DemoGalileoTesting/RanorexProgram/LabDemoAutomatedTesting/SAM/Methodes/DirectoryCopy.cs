﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs = true)
		{
			Report(ReportLevel.Info, "started");
			// Get the subdirectories for the specified directory.
	    	DirectoryInfo dir = new DirectoryInfo(sourceDirName);
	
	    	if (!dir.Exists)
				{
	    	    throw new DirectoryNotFoundException(
	    	    "Source directory does not exist or could not be found: "
	    	    + sourceDirName);
	    	}
	    	DirectoryInfo[] dirs = dir.GetDirectories();
	    	// If the destination directory doesn't exist, create it.
	    	if (!Directory.Exists(destDirName))
	   		{
	    		Report(ReportLevel.Info, "create direcotry " + destDirName);
	        	Directory.CreateDirectory(destDirName);
	   		}
	    	else
	    	{
	    		Report(ReportLevel.Info, "directory " + destDirName + " exsists already");
	    	}
	
	    	// Get the files in the directory and copy them to the new location.
	    	Report(ReportLevel.Info, "Start Copying Process.... .");
	    	FileInfo[] files = dir.GetFiles();
	    	foreach (FileInfo file in files)
	   		{
	        	string temppath = Path.Combine(destDirName, file.Name);
	        	file.CopyTo(temppath, true);
	        	Report(ReportLevel.Info, file + " Copy Done ");
	    	}
	
	    	// If copying subdirectories, copy them and their contents to new location.
	    	if (copySubDirs)
	    	{
	            foreach (DirectoryInfo subdir in dirs)
	           {
	                string temppath = Path.Combine(destDirName, subdir.Name);
	                DirectoryCopy(subdir.FullName, temppath, copySubDirs);
	            }
	 	   	}
	    	Report(ReportLevel.Info, "Copying Process Finished");
		}
	}
}