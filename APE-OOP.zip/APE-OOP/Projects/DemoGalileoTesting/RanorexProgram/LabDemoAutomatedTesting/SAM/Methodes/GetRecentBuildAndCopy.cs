﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// This Function will Find the recent build and copy it onto ur specified folder
		/// </summary>
		/// <param name="argDestinationPath"></param>
		/// <param name="argSourcePath"></param>
		/// <returns>Path to setup .exe</returns>
		public static string GetRecentBuildAndCopy(string argDestinationPath, string argSourcePath)
		{
			Report(ReportLevel.Info, "started with " + argDestinationPath + " and " + argSourcePath);
			
			// Get Recent build Name from sourcepath
        	var directory = new DirectoryInfo(argSourcePath);
			var myFile = directory.GetDirectories().OrderByDescending(f => f.LastWriteTime).First();
			Report(ReportLevel.Info, "Recent Build: " + myFile.ToString());
			
			// Create string of recent build with source path
			string sourcePath = Path.Combine(argSourcePath, myFile.ToString());
			Report(ReportLevel.Info, "Source Path: " + sourcePath.ToString());
			
			// Create stiing of recent build and desitnation path
			string targetPath = Path.Combine(argDestinationPath, myFile.ToString());
			Report(ReportLevel.Info, "Target Path: " + targetPath.ToString());
			
			// Copy whole directory into target path
			DirectoryCopy(sourcePath, targetPath);
			Report(ReportLevel.Success, "Finished Copying");
			
			return targetPath;
		}
	}
}
