﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// This Function will uninstall A Software from your computer just give it the proper name
		/// </summary>
		/// <param name="_ProgramName"></param>
		public static void UninstallSoftware(string _ProgramName = "easySoft 7")
	    {
			Report(ReportLevel.Info, "started with" + _ProgramName);
	
			ManagementObject obj = new ManagementObject();
			
			obj = FindManagementObject(_ProgramName);
		
			if (obj != null)
			{
				try // Try to uninstall software
				{
					Report(ReportLevel.Info, "Try to Uninstall");
					obj.InvokeMethod("Uninstall", null);	
					Report(ReportLevel.Success, "Uninstall Process Finished");
				}
				catch // uninstall process was not sucessfull
				{
					Report(ReportLevel.Failure, "Faild Uninstall Process");
					return;
				}
			}
			else // if obj is null Give Warn there is no Software installed
			{
				Report(ReportLevel.Success, "ManagementObject = null, There is no Software installed.");
				return;
			}
			
			// Uninstall Validation
			Report(ReportLevel.Info, "Validate if " + _ProgramName + " proberly uninstalled");
			ManagementObject objValidation = new ManagementObject();
			
			objValidation = FindManagementObject(_ProgramName);
			
			if (objValidation == null)
			{
				Report(ReportLevel.Success, _ProgramName + " was not found");
			}
			else
			{
				Report(ReportLevel.Failure, _ProgramName + " was found");
			}
		}
		
		/// <summary>
		/// Will Find the software which has to be uninstalled
		/// </summary>
		/// <param name="_ProgramName"></param>
		/// <returns></returns>
		private static ManagementObject FindManagementObject(string _ProgramName)
		{
			Report(ReportLevel.Info, "started with" + _ProgramName);
			
			try // try to do all
	        {
				Report(ReportLevel.Info, "Create ManagementObjectSearcher");
	            ManagementObjectSearcher mos = new ManagementObjectSearcher(
	              "SELECT * FROM Win32_Product WHERE Name = '" + _ProgramName + "'");
	        	
	        	Report(ReportLevel.Info,"Search for " + _ProgramName + " installation in ManagementObjectSearcher.... .");
	            foreach (ManagementObject mo in mos.Get())
	            {
	                try
	                {
	                    if (mo["Name"].ToString() == _ProgramName)
	                    {
	                    	Report(ReportLevel.Success,_ProgramName + " was found");
	                    	return mo;
	                    }
	                }
	                catch
	                {
	                	Report(ReportLevel.Warn, _ProgramName + " has no Name property." );
	                	return null;	
	                }
	            }
	            Report(ReportLevel.Info, _ProgramName + " was not found");
	            return null;
			}
			catch
			{
				Report(ReportLevel.Warn, _ProgramName + " Total Fail" );	
				return null;
			}          
		}
	}	
}

