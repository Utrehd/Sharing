﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 6/16/2017
// Time: 8:05 AM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

namespace SAM
{
	/// <summary>
	/// Description of Logger.
	/// </summary>
	public static class Logger
	{
		private const char borderSymbol = '#';
		private const string newLine = "\r\n";
		private static string  loggerMessage;
		private static ReportLevel logReportLevel = ReportLevel.Info;
		
		private static string LoggerMessage {
			get { return loggerMessage; }
			set { loggerMessage = value; }
		}
		
		public static void CreateNew(string _Title)
		{
			ClearLog();
			_Title += " ";
			LogTitle(_Title);
			logReportLevel = ReportLevel.Info;
		}
		
		public static void LogTitle(string _Title)
		{
			LoggerMessage += AppendRight(_Title);
			LogNewLine(2);
		}
		
		public static void LogMethod(int _Index = 2)
		{
			// Get call stack
			StackTrace stackTrace = new StackTrace();

			// Get calling method name
			LogInfo("Calling Method: (" + stackTrace.GetFrame(_Index).GetMethod().Name + ")");
		}
		public static void LogClass(int _Index = 2)
		{
			// Get call stack
			StackTrace stackTrace = new StackTrace();

			// Get calling method name
			LogInfo("Calling Class: (" + stackTrace.GetFrame(_Index).GetMethod().DeclaringType + ")");
		}
		
		public static void LogInfo(string _Message)
		{
			LoggerMessage += _Message;
			LogNewLine();
		}
		
		public static void LogSucess(string _Message)
		{
			LoggerMessage += _Message;
			LogNewLine();
			
			// Determind of there is already some failure
			if (!(logReportLevel == ReportLevel.Failure || logReportLevel == ReportLevel.Failure))
			{
				logReportLevel = ReportLevel.Success;
			}
		}
		
		public static void LogFailure(string _Message)
		{
			LoggerMessage += _Message;
			LogNewLine();
			logReportLevel = ReportLevel.Failure;
		}
		
		public static void LogError(string _Message)
		{
			LoggerMessage += _Message;
			LogNewLine();
			logReportLevel = ReportLevel.Error;
		}
		
		public static void ReportLog()
		{
			LogNewLine();
			LoggerMessage += AppendRight();
			// write the Log into the ranorex log
			Ranorex.Report.Log(logReportLevel, LoggerMessage);
		}
		
		public static void ClearLog()
		{
			LoggerMessage = "";
		}
		
		public static void LogUnderTitle(string _UnderTitle)
		{
			LogNewLine();
			LoggerMessage += AppendRight(_UnderTitle, 20);
			LogNewLine();
		}
		
		public static string GetLog()
		{
			return LoggerMessage;	
		}
		
		private static string AppendRight(string _Message = "", int _MaxChars = 38)
		{
			return _Message.PadRight(_MaxChars, borderSymbol);
		}

		public static void LogNewLine(int _amount = 1)
		{
			for (int i = 0; i < _amount; i++) {
				LoggerMessage += newLine;	
			}
		}
	}
}
