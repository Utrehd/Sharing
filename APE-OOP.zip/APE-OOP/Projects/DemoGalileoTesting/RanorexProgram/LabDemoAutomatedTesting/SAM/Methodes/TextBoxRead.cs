﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// Read the Text of a Text Box
		/// </summary>
		/// <param name="argTextBox"></param>
		/// <returns></returns>
		public static string TextBoxRead(RepoItemInfo  _TextBox)
		{
			// Assign Text
			Ranorex.Text textBox;
			textBox = _TextBox.CreateAdapter<Ranorex.Text>(true);
			
			Report(ReportLevel.Info, "started with " + textBox);
			// Click on Text Box
			Click(_TextBox);
			
			// Select All
			Keyboard.Down(Keys.Control);
			Keyboard.Press(Keys.A);
			Keyboard.Up(Keys.Control);
			
			// Copy into Clipboard
			Keyboard.Down(Keys.Control);
			Keyboard.Press(Keys.C);
			Keyboard.Up(Keys.Control);
			
			// Save in String and return
			string message;
			message = System.Windows.Forms.Clipboard.GetText();
			Report(ReportLevel.Info, "Read " + message);
			return message;
		}
	}
	
}
