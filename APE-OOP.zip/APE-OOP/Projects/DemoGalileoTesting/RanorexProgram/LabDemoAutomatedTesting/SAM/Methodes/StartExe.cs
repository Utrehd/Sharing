﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Diagnostics;
#endregion

namespace SAM
{
	public partial class Methods
	{
		public static void StartExe(string targetDir)
		{
			Report(ReportLevel.Info, "started with" + targetDir);
			if (File.Exists(targetDir))
			{
				Report(ReportLevel.Success, targetDir + " Setup was Found");
		    	Process.Start(targetDir);
			}
			else
			{
				Report(ReportLevel.Failure, targetDir + " Setup was not Found");
			}	
		}
	}	
}
