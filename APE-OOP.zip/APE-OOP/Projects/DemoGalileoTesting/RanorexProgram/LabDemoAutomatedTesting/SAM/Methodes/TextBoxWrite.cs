﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
#endregion

namespace SAM
{
	public partial class Methods
	{
		/// <summary>
		/// Write into a TextBox
		/// </summary>
		public static void TextBoxWrite(RepoItemInfo _TextBox, string _Text)
		{
			Ranorex.Text textBox;
			textBox = _TextBox.CreateAdapter<Ranorex.Text>(true);
			Report(ReportLevel.Info, "started with" + _TextBox + " and " + _Text);
			// Click on Text Box
			Click(_TextBox);
			
			// Select All and delete
			Keyboard.Down(Keys.Control);
			Keyboard.Press(Keys.A);
			Keyboard.Up(Keys.Control);
			Keyboard.Press(Keys.Delete);
			
			// Wirte Text
			textBox.PressKeys(_Text);
			
			// Enter
			// Keyboard.Press(Keys.Enter);
			
			// Validate
			if(TextBoxRead(_TextBox) == _Text)
			{
				Report(ReportLevel.Success, "Done Correctly");
			}
			else
			{
				Report(ReportLevel.Failure, "Text is Wrong");
			}
		}
	}
}

