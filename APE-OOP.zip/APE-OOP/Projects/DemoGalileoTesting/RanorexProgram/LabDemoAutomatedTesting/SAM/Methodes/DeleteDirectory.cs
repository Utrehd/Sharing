﻿#region Header Info
/*
 * Created by Ranorex
 * User: E9955465
 * Date: 5/24/2017
 * Time: 2:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 #endregion

#region Libraries
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

namespace SAM
{
	public partial class Methods
	{
		public static void DeleteDirectory(string _TargetDir, double _TimeOut = 1000)
		{
			// Check if exsiting
			if(Directory.Exists(_TargetDir))
			{
				try
				{
					// Delete it
					Report(ReportLevel.Info, "Start Deleting.... .");
					Directory.Delete(_TargetDir, true);
					
					// Check if Deleted
					Stopwatch stopwatch = new Stopwatch();
					stopwatch.Start();
					while(stopwatch.ElapsedMilliseconds < _TimeOut)
					{
						if(!Directory.Exists(_TargetDir))
						{
					   		Report(ReportLevel.Success, _TargetDir + " was Sucessful Deleted");
					   		return;
						}
					}
					
					Report(ReportLevel.Failure, _TargetDir + " was not Deleted");
				}
				catch
				{
					Report(ReportLevel.Failure, _TargetDir + " Couldent Delete Directory");
				}
			}
			else
			{
				Report(ReportLevel.Warn, _TargetDir + " Directory does not exsist");
			}
		}
	}
}
