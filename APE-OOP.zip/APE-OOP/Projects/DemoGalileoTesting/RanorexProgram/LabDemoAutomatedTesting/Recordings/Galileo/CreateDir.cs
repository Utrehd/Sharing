﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 8/7/2017
// Time: 5:35 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

#region #### DECLARATIONS ####

#endregion

#region #### CONSTRUCTOR ####

#endregion

#region #### METHODES ####

#endregion

namespace LabDemoAutomatedTesting.Recordings.Galileo
{
	
    /// <summary>
    /// Description of CreateDir.
    /// </summary>
    [TestModule("C230F42C-CF17-4A7B-A2C1-B560FDDFD8C7", ModuleType.UserCode, 1)]
    public class CreateDir : ITestModule
    {
    	
    	string _Dir = "";
    	[TestVariable("f6d80448-7af8-49e3-8685-0b9d4a605a77")]
    	public string DirCreate
    	{
    		get { return _Dir; }
    		set { _Dir = value; }
    	}
    	
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public CreateDir()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            Directory.CreateDirectory(DirCreate);
        }
    }
}
