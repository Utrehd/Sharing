﻿#region #### INFO ####
// Created by Ranorex
// User: E9955465
// Date: 8/7/2017
// Time: 5:10 PM
// Description:
//  
#endregion

#region #### LIBRARIES ####
using System;
using System.IO;
using System.Linq;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;
using Ranorex.Core.Repository;
using Ranorex.Core.Reporting;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using WinForms = System.Windows.Forms;
using System.Management;
using System.Diagnostics;
#endregion

#region #### DECLARATIONS ####

#endregion

#region #### CONSTRUCTOR ####

#endregion

#region #### METHODES ####

#endregion

namespace LabDemoAutomatedTesting.Recordings
{
    /// <summary>
    /// Description of DeleteDir.
    /// </summary>
    [TestModule("501648AA-95A3-4932-BAA4-8C80F02207FC", ModuleType.UserCode, 1)]
    public class DeleteDir : ITestModule
    {
    	
    	string _Dir = "";
    	[TestVariable("5c5e37c4-42bf-4687-bbc5-dd7e2514e86d")]
    	public string Dir
    	{
    		get { return _Dir; }
    		set { _Dir = value; }
    	}
    	
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public DeleteDir()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            DeleteDirectory(Dir);
            
        }
        
        public static void DeleteDirectory(string _TargetDir, double _TimeOut = 1000)
		{
			// Check if exsiting
			if(Directory.Exists(_TargetDir))
			{
				try
				{
					// Delete it
					Ranorex.Report.Log(ReportLevel.Info, "Start Deleting.... .");
					Directory.Delete(_TargetDir, true);
					
					// Check if Deleted
					Stopwatch stopwatch = new Stopwatch();
					stopwatch.Start();
					while(stopwatch.ElapsedMilliseconds < _TimeOut)
					{
						if(!Directory.Exists(_TargetDir))
						{
					   		Ranorex.Report.Log(ReportLevel.Success, _TargetDir + " was Sucessful Deleted");
					   		return;
						}
					}
					
					Ranorex.Report.Log(ReportLevel.Failure, _TargetDir + " was not Deleted");
				}
				catch
				{
					Ranorex.Report.Log(ReportLevel.Failure, _TargetDir + " Couldent Delete Directory");
				}
			}
			else
			{
				Ranorex.Report.Log(ReportLevel.Warn, _TargetDir + " Directory does not exsist");
			}
		}
    }
}
